import java.awt.image.BufferedImage;
import java.io.InputStream;
import java.nio.FloatBuffer;
import java.util.Properties;
import org.lwjgl.BufferUtils;
import org.lwjgl.opengl.GL11;

/**
 * Cloud Layers for Alpha 1.1.2_01 and Beta 1.7.3: three cloud layers instead of one, with the settings in
 * cloudlayers_settings.txt. The game's cloud render passes through CloudLayersGame (one per version, the only code
 * that knows the game's names); render() draws all the layers and returns true, or false to let the game draw its
 * own clouds (enabled=false, or a dimension without clouds).
 *
 * Distance: the far clip plane is pushed out while clouds draw and every vertex fades to transparent before it, so
 * clouds melt into the sky instead of being sliced at the render distance. On Short and Tiny (no sky drawn) the
 * clouds keep the game's own fog and disappear into it like vanilla clouds. Faces are cut into pieces small enough
 * for the per-vertex fade to stay smooth.
 *
 * Speed: each layer's geometry is a display list, rebuilt only when its settings change or the camera moves a few
 * blocks up or down; each frame only moves it (modelview and texture matrix). The cloud color comes through GL
 * lighting (no lights, light-model ambient = cloud color, the vertex colors carry the face shade and fade), so day,
 * night and weather need no rebuild.
 *
 * Textures: layer 1 is the game's clouds.png; layers 2 and 3 (texture=auto) are made in code from the clouds.png in
 * use, turned and shifted so the layers never line up, and made again when the texture pack changes.
 *
 * alt_clouds: the shaded faces (undersides, sides) of layers 1 and 2, when 3D, take 75%
 * of the hue of the sky they
 * are seen against: the fog color, which is the sky color at the horizon where the clouds fade out (it follows
 * sunrise, sunset, night and weather), and fades out toward midnight (nightFade). Layer 3 is not changed.
 */
public final class CloudLayers {
    static final int LAYERS = 3;
    static boolean enabled = true;
    static float baseHeight = 108.0F;
    static float spacing = 32.0F;
    static float fastOffset = 0.0F;
    static float distanceMultiplier = 2.0F;
    static float minDistance = 128.0F;
    static float fadeStart = 0.5F;
    static boolean altClouds = false;
    /** How much of the sky's hue alt_clouds mixes into the shaded faces (picked by the user from 30/50/75/100%). */
    static final float SKY_MIX = Float.parseFloat(System.getProperty("cloudlayers.skymix", "75")) / 100.0F;
    /** alt_clouds_night_fade: the tint fades out toward midnight (false = the same tint all night). */
    static boolean altNightFade = true;
    static final float[] alpha = {0.8F, 0.65F, 0.35F};
    static final float[] speed = {1.0F, 1.0F, 1.0F};
    /** Color multiplier per layer (1 = the game's cloud color; above 1 the shaded faces get lighter). */
    static final float[] brightness = {1.0F, 1.0F, 1.0F};
    static final boolean[] fancy = {true, true, false};
    /** "auto" = made from the clouds texture in use (layer 1: it as it is), else a png path in the jar / pack. */
    static final String[] texture = {"auto", "auto", "auto"};
    static boolean loaded;

    // this frame's fade: where fading begins and where clouds are gone
    static float fadeNear, fadeFar;
    static final FloatBuffer matrix = BufferUtils.createFloatBuffer(16);
    static final FloatBuffer scratch = BufferUtils.createFloatBuffer(16);
    static final FloatBuffer light = BufferUtils.createFloatBuffer(4);

    // per layer: display list and what it was built with
    static final int DY_STEP = 4;
    static final int[] list = new int[LAYERS];
    static final boolean[] builtFancy = new boolean[LAYERS];
    static final float[] builtAlpha = new float[LAYERS];
    static final float[] builtFar = new float[LAYERS];
    static final float[] builtNear = new float[LAYERS];
    static final int[] builtDy = new int[LAYERS];
    static final int[] builtSeg = new int[LAYERS];
    // this frame's piece size: cells per piece (3D) and blocks per quad (flat)
    static int fancySeg = 8, fastSeg = 32;
    static float vertDy;

    // textures made in code for layers 2 and 3, and the texture pack they were made from
    static final int[] madeTexture = new int[LAYERS];
    static Object madeFrom = CloudLayers.class;

    private CloudLayers() {
    }

    static void load() {
        loaded = true;
        Properties p = new Properties();
        try (InputStream in = CloudLayers.class.getResourceAsStream("/cloudlayers_settings.txt")) {
            if (in == null) return;
            p.load(in);
        } catch (Exception ex) {
            System.out.println("[CloudLayers] could not read cloudlayers_settings.txt: " + ex);
            return;
        }
        enabled = !"false".equalsIgnoreCase(p.getProperty("enabled", "true").trim());
        baseHeight = num(p, "base_height", baseHeight);
        spacing = num(p, "spacing", spacing);
        fastOffset = num(p, "fast_offset", fastOffset);
        distanceMultiplier = num(p, "cloud_distance", distanceMultiplier);
        minDistance = num(p, "min_cloud_distance", minDistance);
        fadeStart = Math.max(0.0F, Math.min(0.99F, num(p, "fade_start", fadeStart)));
        altClouds = "true".equalsIgnoreCase(p.getProperty("alt_clouds", "false").trim());
        altNightFade = !"false".equalsIgnoreCase(p.getProperty("alt_clouds_night_fade", "true").trim());
        for (int i = 0; i < LAYERS; i++) {
            String k = "layer" + (i + 1) + ".";
            alpha[i] = num(p, k + "alpha", alpha[i]);
            speed[i] = num(p, k + "speed", speed[i]);
            brightness[i] = Math.max(0.0F, num(p, k + "brightness", brightness[i]));
            texture[i] = p.getProperty(k + "texture", texture[i]).trim();
            fancy[i] = !"fast".equalsIgnoreCase(p.getProperty(k + "style", fancy[i] ? "fancy" : "fast").trim());
        }
    }

    static float num(Properties p, String key, float def) {
        String v = p.getProperty(key);
        if (v == null) return def;
        try {
            return Float.parseFloat(v.trim());
        } catch (NumberFormatException ex) {
            System.out.println("[CloudLayers] bad value for " + key + ": " + v);
            return def;
        }
    }

    /** Draws every layer; false = let the game draw its own clouds. */
    static boolean render() {
        if (!loaded) load();
        if (!enabled || CloudLayersGame.noClouds()) return false;
        double camY = CloudLayersGame.camY();
        boolean fancyGfx = CloudLayersGame.fancyGraphics();
        int dist = CloudLayersGame.renderDistance();

        float range = Math.max((float) (256 >> dist) * distanceMultiplier, minDistance);
        fadeFar = range;
        fadeNear = range * fadeStart;
        boolean linearFog = GL11.glIsEnabled(GL11.GL_FOG) && GL11.glGetInteger(GL11.GL_FOG_MODE) == GL11.GL_LINEAR;
        float oldFogStart = linearFog ? getFloat(GL11.GL_FOG_START) : 0.0F, oldFogEnd = linearFog ? getFloat(GL11.GL_FOG_END) : 0.0F;
        // Short/Tiny (no sky drawn): keep the game's fog; clouds are gone by its end
        boolean gameFog = linearFog && dist >= 2 && oldFogEnd > 0.0F;
        if (gameFog) {
            fadeNear = oldFogEnd;
            fadeFar = oldFogEnd * 1.25F;
            range = fadeFar;
        }
        float fogStart = gameFog ? oldFogStart : range * 0.25F, fogEnd = gameFog ? oldFogEnd : range * 1.25F;
        float smooth = fadeFar - fadeNear;
        if (linearFog) smooth = Math.min(smooth, fogEnd - fogStart);
        fancySeg = smooth >= 768.0F ? 8 : smooth >= 384.0F ? 4 : smooth >= 192.0F ? 2 : 1;
        fastSeg = smooth >= 256.0F ? 32 : smooth >= 128.0F ? 16 : 8;

        // far clip plane pushed out past the fade, so nothing gets sliced
        matrix.clear();
        GL11.glGetFloat(GL11.GL_PROJECTION_MATRIX, matrix);
        float near = 0.05F, far = range + 64.0F;
        matrix.put(10, -(far + near) / (far - near));
        matrix.put(14, -2.0F * far * near / (far - near));
        GL11.glMatrixMode(GL11.GL_PROJECTION);
        GL11.glPushMatrix();
        GL11.glLoadMatrix(matrix);
        GL11.glMatrixMode(GL11.GL_MODELVIEW);
        // Far/Normal: linear fog stretched over the same range, so its tint matches the fade
        if (linearFog && !gameFog) {
            GL11.glFogf(GL11.GL_FOG_START, fogStart);
            GL11.glFogf(GL11.GL_FOG_END, fogEnd);
        }
        // fully faded fragments must not write depth (that would hide nearer layers and particles)
        boolean alphaTest = GL11.glIsEnabled(GL11.GL_ALPHA_TEST);
        int alphaFunc = GL11.glGetInteger(GL11.GL_ALPHA_TEST_FUNC);
        float alphaRef = getFloat(GL11.GL_ALPHA_TEST_REF);
        GL11.glEnable(GL11.GL_ALPHA_TEST);
        GL11.glAlphaFunc(GL11.GL_GREATER, 0.01F);
        // cloud color through lighting: no lights, ambient = cloud color, color material = the baked shade and fade
        GL11.glPushAttrib(GL11.GL_LIGHTING_BIT | GL11.GL_ENABLE_BIT);
        float[] col = anaglyph(CloudLayersGame.cloudColor());
        float[] sky = altClouds ? nightFade(fogColor(), CloudLayersGame.celestialAngle()) : null;
        GL11.glEnable(GL11.GL_LIGHTING);
        for (int l = 0; l < 8; l++) GL11.glDisable(GL11.GL_LIGHT0 + l);
        GL11.glEnable(GL11.GL_COLOR_MATERIAL);
        GL11.glColorMaterial(GL11.GL_FRONT_AND_BACK, GL11.GL_AMBIENT_AND_DIFFUSE);

        // farthest layer first, so the translucent layers blend correctly
        int[] order = {0, 1, 2};
        for (int i = 0; i < LAYERS; i++)
            for (int j = i + 1; j < LAYERS; j++)
                if (Math.abs(height(order[j]) - camY) > Math.abs(height(order[i]) - camY)) {
                    int t = order[i];
                    order[i] = order[j];
                    order[j] = t;
                }
        try {
            for (int i : order) {
                if (alpha[i] <= 0.0F) continue;
                boolean f = fancyGfx && fancy[i];
                float h = f ? height(i) : height(i) + fastOffset;
                ensureList(i, f, h - (float) camY);
                if (sky != null && f && i <= 1) setSkyShading(col, sky, brightness[i]);
                else setShading(col, brightness[i], 0.0F, 0.0F, 0.0F);
                GL11.glPushMatrix();
                draw(i, f, h, (float) camY);
                GL11.glPopMatrix();
            }
        } finally {
            GL11.glPopAttrib();
            GL11.glAlphaFunc(alphaFunc, alphaRef);
            if (!alphaTest) GL11.glDisable(GL11.GL_ALPHA_TEST);
            if (linearFog) {
                GL11.glFogf(GL11.GL_FOG_START, oldFogStart);
                GL11.glFogf(GL11.GL_FOG_END, oldFogEnd);
            }
            GL11.glMatrixMode(GL11.GL_PROJECTION);
            GL11.glPopMatrix();
            GL11.glMatrixMode(GL11.GL_MODELVIEW);
        }
        return true;
    }

    static float getFloat(int name) {
        scratch.clear();
        GL11.glGetFloat(name, scratch);
        return scratch.get(0);
    }

    static float height(int layer) {
        return baseHeight + spacing * (float) layer;
    }

    /** Lit color = ambient * vertex shade + emission. Plain: ambient = cloud color * k, no emission. */
    static void setShading(float[] col, float k, float er, float eg, float eb) {
        light.clear();
        light.put(col[0] * k).put(col[1] * k).put(col[2] * k).put(1.0F).flip();
        GL11.glLightModel(GL11.GL_LIGHT_MODEL_AMBIENT, light);
        light.clear();
        light.put(er).put(eg).put(eb).put(0.0F).flip();
        GL11.glMaterial(GL11.GL_FRONT_AND_BACK, GL11.GL_EMISSION, light);
    }

    /**
     * alt_clouds: 3D faces carry their vanilla shade s as vertex color (top 1, sides 0.9 / 0.8, bottom 0.7) and the lit
     * color ambient * s + emission is linear in s: the top stays the cloud color, the bottom is 0.7 * cloud * tint with
     * tint = 1 + SKY_MIX * (sky / luminance(sky) - 1), the sky's hue at the same darkness.
     */
    static void setSkyShading(float[] col, float[] sky, float k) {
        float lum = sky[0] * 0.3F + sky[1] * 0.59F + sky[2] * 0.11F;
        float[] a = new float[3], e = new float[3];
        for (int c = 0; c < 3; c++) {
            float tint = 1.0F + SKY_MIX * ((lum > 0.001F ? sky[c] / lum : 1.0F) - 1.0F);
            float top = col[c] * k, bottom = 0.7F * top * tint;
            a[c] = (top - bottom) / 0.3F;
            e[c] = top - a[c];
        }
        light.clear();
        light.put(a[0]).put(a[1]).put(a[2]).put(1.0F).flip();
        GL11.glLightModel(GL11.GL_LIGHT_MODEL_AMBIENT, light);
        light.clear();
        light.put(e[0]).put(e[1]).put(e[2]).put(0.0F).flip();
        GL11.glMaterial(GL11.GL_FRONT_AND_BACK, GL11.GL_EMISSION, light);
    }

    /** The fog color the game set for this frame: the sky at the horizon, where the clouds fade into it. */
    static float[] fogColor() {
        scratch.clear();
        GL11.glGetFloat(GL11.GL_FOG_COLOR, scratch);
        return new float[] {scratch.get(0), scratch.get(1), scratch.get(2)};
    }

    /**
     * The tint fades out at night: full all day, then from sunset it eases down to none at midnight and back up to full
     * by sunrise (k = 1 + cos(2 pi angle), clamped to 0..1). Done by moving the sky color toward its own gray, which
     * scales the tint by k and keeps the brightness.
     */
    static float[] nightFade(float[] sky, float angle) {
        if (!altNightFade) return sky;
        float k = Math.max(0.0F, Math.min(1.0F, 1.0F + (float) Math.cos(angle * Math.PI * 2.0D)));
        float lum = sky[0] * 0.3F + sky[1] * 0.59F + sky[2] * 0.11F;
        return new float[] {lum + k * (sky[0] - lum), lum + k * (sky[1] - lum), lum + k * (sky[2] - lum)};
    }

    static float[] anaglyph(float[] c) {
        if (!CloudLayersGame.anaglyph()) return c;
        float r = c[0], g = c[1], b = c[2];
        return new float[] {(r * 30.0F + g * 59.0F + b * 11.0F) / 100.0F, (r * 30.0F + g * 70.0F) / 100.0F, (r * 30.0F + b * 70.0F) / 100.0F};
    }

    // --- textures ---

    /** The texture of layer i. */
    static int texture(int i) {
        if (!texture[i].equalsIgnoreCase("auto")) return CloudLayersGame.texture(texture[i]);
        if (i == 0) return CloudLayersGame.texture(CloudLayersGame.CLOUDS);
        Object pack = CloudLayersGame.pack();
        if (pack != madeFrom || madeTexture[i] == 0) {
            madeFrom = pack;
            try {
                BufferedImage src = CloudLayersGame.image(CloudLayersGame.CLOUDS);
                if (src != null)
                    for (int k = 1; k < LAYERS; k++) madeTexture[k] = CloudLayersGame.upload(layerImage(src, k), madeTexture[k]);
            } catch (Exception ex) {
                System.out.println("[CloudLayers] could not make the layer textures: " + ex);
            }
        }
        return madeTexture[i] != 0 ? madeTexture[i] : CloudLayersGame.texture(CloudLayersGame.CLOUDS);
    }

    /**
     * Layer 2: clouds.png turned 90 degrees left and shifted by (97, 41) of 256. Layer 3: mirrored, turned 90 degrees
     * right and shifted by (173, 131) of 256. Shifts scale with the texture size.
     */
    static BufferedImage layerImage(BufferedImage src, int layer) {
        int w = src.getWidth(), h = src.getHeight(), n = Math.min(w, h);
        int dx = (layer == 1 ? 97 : 173) * n / 256, dy = (layer == 1 ? 41 : 131) * n / 256;
        BufferedImage out = new BufferedImage(n, n, BufferedImage.TYPE_INT_ARGB);
        for (int y = 0; y < n; y++)
            for (int x = 0; x < n; x++) {
                int sx = Math.floorMod(x - dx, n), sy = Math.floorMod(y - dy, n);
                out.setRGB(x, y, layer == 1 ? src.getRGB(n - 1 - sy, sx) : src.getRGB(n - 1 - sy, n - 1 - sx));
            }
        return out;
    }

    // --- geometry ---

    /** Rebuilds layer i's display list if anything it was built with has changed. */
    static void ensureList(int i, boolean f, float relY) {
        int dy = Math.round(relY / (float) DY_STEP), seg = f ? fancySeg : fastSeg;
        if (list[i] != 0 && builtFancy[i] == f && builtAlpha[i] == alpha[i] && builtFar[i] == fadeFar && builtNear[i] == fadeNear
            && builtDy[i] == dy && builtSeg[i] == seg) return;
        if (list[i] == 0) list[i] = GL11.glGenLists(1);
        builtFancy[i] = f;
        builtAlpha[i] = alpha[i];
        builtFar[i] = fadeFar;
        builtNear[i] = fadeNear;
        builtDy[i] = dy;
        builtSeg[i] = seg;
        vertDy = (float) (dy * DY_STEP);
        GL11.glNewList(list[i], GL11.GL_COMPILE);
        if (f) buildFancy(alpha[i], seg);
        else buildFast(alpha[i], seg);
        GL11.glEndList();
    }

    /** A vertex with its shade and distance fade baked in; hs = the geometry's horizontal scale. */
    static void vert(float hs, float shade, float a, float x, float y, float z, float u, float v) {
        float dx = x * hs, dz = z * hs, dy = y + vertDy;
        float d = (float) Math.sqrt(dx * dx + dy * dy + dz * dz), f = 1.0F;
        if (d >= fadeFar) f = 0.0F;
        else if (d > fadeNear) {
            f = 1.0F - (d - fadeNear) / (fadeFar - fadeNear);
            f = f * f * (3.0F - 2.0F * f);
        }
        CloudLayersGame.color(shade, shade, shade, a * f);
        CloudLayersGame.vertex(x, y, z, u, v);
    }

    /** Flat plane centred on the camera at local y 0 (vanilla fast clouds); the texture matrix scrolls it. */
    static void buildFast(float a, int size) {
        int count = (int) Math.ceil(fadeFar / (float) size) + 1;
        float uv = 4.8828125E-4F;
        CloudLayersGame.begin();
        for (int i = -size * count; i < size * count; i += size)
            for (int j = -size * count; j < size * count; j += size) {
                float i1 = i + size, j1 = j + size;
                vert(1.0F, 1.0F, a, i, 0.0F, j1, i * uv, j1 * uv);
                vert(1.0F, 1.0F, a, i1, 0.0F, j1, i1 * uv, j1 * uv);
                vert(1.0F, 1.0F, a, i1, 0.0F, j, i1 * uv, j * uv);
                vert(1.0F, 1.0F, a, i, 0.0F, j, i * uv, j * uv);
            }
        CloudLayersGame.draw();
    }

    /**
     * Vanilla fancy 3D clouds in cloud units (x12 horizontally), camera in cell 0. Top and bottom faces are both kept,
     * so the list works from any height (the depth pre-pass lets only the nearest surface through). Faces are cut
     * into n x n cell pieces so the per-vertex fade and fog stay smooth.
     */
    static void buildFancy(float a, int n) {
        float scale = 12.0F, thick = 4.0F, px = 0.00390625F, eps = 9.765625E-4F, top = thick - eps;
        int cell = 8, radius = (int) Math.ceil(fadeFar / (cell * scale)) + 1;
        CloudLayersGame.begin();
        for (int cx = -radius; cx <= radius; cx++)
            for (int cz = -radius; cz <= radius; cz++) {
                float ox = (float) (cx * cell), oz = (float) (cz * cell);
                // cells entirely past the fade are left out
                float nx = Math.max(0.0F, Math.max(ox - 1.0F, -(ox + cell))) * scale, nz = Math.max(0.0F, Math.max(oz - 1.0F, -(oz + cell))) * scale;
                if (nx * nx + nz * nz >= fadeFar * fadeFar) continue;
                for (int i = 0; i < cell; i += n)
                    for (int j = 0; j < cell; j += n) {
                        float x0 = ox + i, x1 = x0 + n, z0 = oz + j, z1 = z0 + n, u0 = x0 * px, u1 = x1 * px, v0 = z0 * px, v1 = z1 * px;
                        vert(scale, 0.7F, a, x0, 0.0F, z1, u0, v1);
                        vert(scale, 0.7F, a, x1, 0.0F, z1, u1, v1);
                        vert(scale, 0.7F, a, x1, 0.0F, z0, u1, v0);
                        vert(scale, 0.7F, a, x0, 0.0F, z0, u0, v0);
                        vert(scale, 1.0F, a, x0, top, z1, u0, v1);
                        vert(scale, 1.0F, a, x1, top, z1, u1, v1);
                        vert(scale, 1.0F, a, x1, top, z0, u1, v0);
                        vert(scale, 1.0F, a, x0, top, z0, u0, v0);
                    }
                for (int s = 0; s < cell; s++) {
                    float u = (ox + s + 0.5F) * px, v = (oz + s + 0.5F) * px;
                    for (int j = 0; j < cell; j += n) {
                        float a0 = oz + j, a1 = a0 + n, b0 = ox + j, b1 = b0 + n;
                        if (cx > -1) side(scale, 0.9F, a, ox + s, a0, a1, u, px, true);
                        if (cx <= 1) side(scale, 0.9F, a, ox + s + 1.0F - eps, a0, a1, u, px, true);
                        if (cz > -1) side(scale, 0.8F, a, oz + s, b0, b1, v, px, false);
                        if (cz <= 1) side(scale, 0.8F, a, oz + s + 1.0F - eps, b0, b1, v, px, false);
                    }
                }
            }
        CloudLayersGame.draw();
    }

    /** One side face piece: at x = p (alongX, from z c0 to c1) or at z = p (from x c0 to c1). */
    static void side(float scale, float shade, float a, float p, float c0, float c1, float t, float px, boolean alongX) {
        float thick = 4.0F;
        if (alongX) {
            vert(scale, shade, a, p, 0.0F, c1, t, c1 * px);
            vert(scale, shade, a, p, thick, c1, t, c1 * px);
            vert(scale, shade, a, p, thick, c0, t, c0 * px);
            vert(scale, shade, a, p, 0.0F, c0, t, c0 * px);
        } else {
            vert(scale, shade, a, c0, thick, p, c0 * px, t);
            vert(scale, shade, a, c1, thick, p, c1 * px, t);
            vert(scale, shade, a, c1, 0.0F, p, c1 * px, t);
            vert(scale, shade, a, c0, 0.0F, p, c0 * px, t);
        }
    }

    /** Draws layer i's list: the plane follows the camera and the texture scrolls (3D: depth pre-pass, then color). */
    static void draw(int i, boolean f, float h, float camY) {
        float scale = f ? 12.0F : 1.0F, drift = CloudLayersGame.ticks() * 0.03F * speed[i];
        double x = (CloudLayersGame.camX() + drift) / scale, z = CloudLayersGame.camZ() / scale + (f ? 0.33F : 0.0F);
        x -= Math.floor(x / 2048.0) * 2048.0;
        z -= Math.floor(z / 2048.0) * 2048.0;
        GL11.glDisable(GL11.GL_CULL_FACE);
        GL11.glBindTexture(GL11.GL_TEXTURE_2D, texture(i));
        GL11.glEnable(GL11.GL_BLEND);
        GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
        GL11.glMatrixMode(GL11.GL_TEXTURE);
        GL11.glPushMatrix();
        if (f) {
            float px = 0.00390625F;
            GL11.glTranslatef((float) Math.floor(x) * px, (float) Math.floor(z) * px, 0.0F);
            GL11.glMatrixMode(GL11.GL_MODELVIEW);
            GL11.glScalef(scale, 1.0F, scale);
            GL11.glTranslatef(-(float) (x - Math.floor(x)), h - camY + 0.33F, -(float) (z - Math.floor(z)));
            GL11.glColorMask(false, false, false, false);
            GL11.glCallList(list[i]);
            GL11.glColorMask(true, true, true, true);
        } else {
            float uv = 4.8828125E-4F;
            GL11.glTranslatef((float) (x * uv), (float) (z * uv), 0.0F);
            GL11.glMatrixMode(GL11.GL_MODELVIEW);
            GL11.glTranslatef(0.0F, h - camY + 0.33F, 0.0F);
        }
        GL11.glCallList(list[i]);
        GL11.glMatrixMode(GL11.GL_TEXTURE);
        GL11.glPopMatrix();
        GL11.glMatrixMode(GL11.GL_MODELVIEW);
        GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
        GL11.glDisable(GL11.GL_BLEND);
        GL11.glEnable(GL11.GL_CULL_FACE);
    }
}
