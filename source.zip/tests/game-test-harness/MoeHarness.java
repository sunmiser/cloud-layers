import java.io.*;
import java.lang.reflect.*;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.*;
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;

/**
 * Drives the real Minecraft Oldschool Edition client (Vulkan): loads a world, holds the camera at scripted
 * spots and saves what M:OE rendered. Called by Agent before every Display.swapBuffers in Minecraft.run.
 * Shots file lines: name yaw pitch x y z  (y = eye level), or commands that do what the shader menu does:
 *   @opt packId/option value   set a shader pack option, then ShaderPackManager.publish + saveOptions
 *   @shaders                   ShaderPackManager.toggleLighting (the menu's shaders on/off button)
 *   @set x y z blockId         client-side setBlockWithNotify
 * A shot line may end with drop=x,y,z,blockId,frames: after settling, that block is set (client side) and a
 * falling block entity is spawned in the same cell, like the moment sand starts to fall; the next `frames`
 * frames are all saved as name_NN, with each falling block's light sample logged per frame.
 * Everything is reflection, so this compiles
 * without the game. Also logs the fog numbers Warmlighting Final worked out for each shot.
 */
public class MoeHarness {
    static int frame, phase, shot, retries;
    static long until;
    // Frame rate over the last 1.5 s of each shot's settle time (logged with the shot).
    static long fpsStart;
    static int fpsFrames;
    static List<String[]> shots = new ArrayList<String[]>();
    static int[] snowAt;
    static int waitShot = -1;
    static File outDir = new File(System.getProperty("out", "out"));
    static String world = System.getProperty("world", "World");
    static long settleMs = Long.getLong("settleMs", 3000L);
    // Pickup test: a world item that can't be picked up, and a twin drawn through EntityPickupFX.
    static List<Object> heldItems = new ArrayList<Object>();
    static List<double[]> heldPos = new ArrayList<double[]>();
    static int dropLeft = -1, dropN;
    static boolean dropSawSolid, dropSavedAfter, dropStale;
    static int staleCount;

    static Field find(Class<?> c, String f) throws Exception {
        for (Class<?> k = c; k != null; k = k.getSuperclass()) {
            try { Field x = k.getDeclaredField(f); x.setAccessible(true); return x; } catch (NoSuchFieldException e) { }
        }
        throw new NoSuchFieldException(c + "." + f);
    }
    static Object get(Object o, String f) throws Exception { return find(o.getClass(), f).get(o); }
    static void set(Object o, String f, Object v) throws Exception { find(o.getClass(), f).set(o, v); }
    static Method method(Class<?> c, String n, Class<?>... p) throws Exception {
        for (Class<?> k = c; k != null; k = k.getSuperclass()) {
            try { Method m = k.getDeclaredMethod(n, p); m.setAccessible(true); return m; } catch (NoSuchMethodException e) { }
        }
        throw new NoSuchMethodException(c + "." + n);
    }

    public static void frame(Object mc) {
        try { step(mc); } catch (Throwable t) { t.printStackTrace(); System.exit(3); }
    }

    static void step(Object mc) throws Exception {
        frame++;
        if (phase == 0) {
            BufferedReader r = new BufferedReader(new FileReader(System.getProperty("shots")));
            for (String s; (s = r.readLine()) != null; ) { s = s.trim(); if (s.length() > 0 && !s.startsWith("#")) shots.add(s.split("\\s+")); }
            r.close();
            outDir.mkdirs();
            phase = 1;
            until = System.currentTimeMillis() + Long.getLong("bootMs", 6000L);
            return;
        }
        if (phase == 1) {
            if (System.currentTimeMillis() < until) return;
            System.out.println("[MoeHarness] loading world " + world);
            method(mc.getClass(), "startWorld", String.class, String.class, long.class).invoke(mc, world, world, 0L);
            phase = 2;
            until = System.currentTimeMillis() + Long.getLong("firstSettleMs", 12000L);
            return;
        }
        Object w = get(mc, "theWorld"), pl = get(mc, "thePlayer");
        if (w == null || pl == null) return;
        if (get(mc, "currentScreen") != null) method(mc.getClass(), "displayGuiScreen", Class.forName("net.minecraft.src.gui.GuiScreen")).invoke(mc, (Object) null);
        String[] s = shots.get(shot);
        holdItems();
        // cavelog on a camera shot: print Warmlighting's cave fog blend (VoidFog.cave, 0 normal .. 1 cave gray) every frame
        for (String t : s)
            if (t.equals("cavelog")) {
                Class<?> vf = Class.forName("net.minecraft.src.render.world.VoidFog");
                java.lang.reflect.Field cf = vf.getDeclaredField("cave"), of = vf.getDeclaredField("open");
                cf.setAccessible(true); of.setAccessible(true);
                System.out.println("[Harness] cave " + s[0] + " " + System.currentTimeMillis() + " " + cf.getFloat(null) + " " + of.getFloat(null));
            }
        if (s[0].equals("@ground") || s[0].equals("@pickup")) {
            double ix = Double.parseDouble(s[1]), iy = Double.parseDouble(s[2]), iz = Double.parseDouble(s[3]);
            int id = Integer.parseInt(s[4]), meta = Integer.parseInt(s[5]);
            Object stack = Class.forName("net.minecraft.world.item.ItemStack").getConstructor(int.class, int.class, int.class).newInstance(id, 1, meta);
            Class<?> levelC = Class.forName("net.minecraft.world.level.Level");
            Object item = Class.forName("net.minecraft.src.entity.EntityItem")
                .getConstructor(levelC, double.class, double.class, double.class, stack.getClass()).newInstance(w, ix, iy, iz, stack);
            set(item, "delayBeforeCanPickup", Integer.valueOf(1000000));
            heldItems.add(item);
            heldPos.add(new double[] {ix, iy, iz});
            holdItems();
            Object packed = method(w.getClass(), "getPackedWeatherLightComponents", int.class, int.class, int.class)
                .invoke(w, (int) Math.floor(ix), (int) Math.floor(iy), (int) Math.floor(iz));
            if (s[0].equals("@ground")) {
                method(w.getClass(), "entityJoinedWorld", Class.forName("net.minecraft.world.entity.Entity")).invoke(w, item);
            } else {
                Class<?> ent = Class.forName("net.minecraft.world.entity.Entity");
                Object fx = Class.forName("net.minecraft.src.render.particle.EntityPickupFX")
                    .getConstructor(levelC, ent, ent, float.class).newInstance(w, item, pl, 0.0F);
                // Hold the animation at its first instant (the item's own spot) and never let it end.
                set(fx, "field_677_q", Integer.valueOf(1000000000));
                Object er = get(mc, "effectRenderer");
                method(er.getClass(), "addEffect", Class.forName("net.minecraft.src.render.particle.EntityFX")).invoke(er, fx);
            }
            System.out.println("[MoeHarness] " + s[0] + " item " + id + ":" + meta + " at " + ix + "," + iy + "," + iz + " packed light " + packed);
            shot++;
            until = System.currentTimeMillis() + settleMs;
            return;
        }
        if (s[0].startsWith("@")) {
            Object gs = get(mc, "gameSettings");
            Class<?> spm = Class.forName("net.minecraft.src.render.shader.ShaderPackManager");
            if (s[0].equals("@findsnow")) {
                // @findsnow [maxRadius]: the nearest column of a snowy biome (getEnableSnow) within maxRadius (default
                // 1500) of the player, snowy 16 blocks around. Camera shots and @put after this are relative to it; y is
                // relative to its top block once that has been measured (the first @put, after a shot there loaded it),
                // absolute before.
                Object wcm = method(w.getClass(), "getWorldChunkManager").invoke(w);
                Method at = method(wcm.getClass(), "getBiomeGenAt", int.class, int.class);
                Method id = method(w.getClass(), "getBlockId", int.class, int.class, int.class);
                int x0 = (int) (double) (Double) get(pl, "posX"), z0 = (int) (double) (Double) get(pl, "posZ");
                int max = s.length > 1 ? Integer.parseInt(s[1]) : 1500;
                search:
                for (int r = 0; r <= max; r += 4)
                    for (int dx = -r; dx <= r; dx += 4)
                        for (int dz = -r; dz <= r; dz += 4) {
                            if (Math.max(Math.abs(dx), Math.abs(dz)) != r) continue;
                            int bx = x0 + dx, bz = z0 + dz;
                            boolean all = true;
                            for (int ox = -16; ox <= 16 && all; ox += 8) for (int oz = -16; oz <= 16 && all; oz += 8) {
                                Object c = at.invoke(wcm, bx + ox, bz + oz);
                                all = c != null && (Boolean) method(c.getClass(), "getEnableSnow").invoke(c);
                            }
                            if (!all) continue;
                            snowAt = new int[] {bx, bz, -1};
                            System.out.println("[MoeHarness] snowy biome " + get(at.invoke(wcm, bx, bz), "biomeName") + " at " + bx + "," + bz);
                            break search;
                        }
                if (snowAt == null) { System.out.println("[MoeHarness] no snowy biome within " + max); Runtime.getRuntime().halt(6); }
                shot++;
                until = System.currentTimeMillis() + settleMs;
                return;
            }
            if (s[0].equals("@weather")) {
                // @weather snow|clear: rain (snow in cold biomes) on or off, in the server world and the client world.
                boolean on = s[1].equals("snow");
                Object sw = null;
                try { sw = get(get(mc, "integratedServerRuntime"), "world"); } catch (Exception ex) { }
                for (Object lw : new Object[] {sw, w}) {
                    if (lw == null) continue;
                    Object wi = get(lw, "worldInfo");
                    method(wi.getClass(), "setRaining", boolean.class).invoke(wi, on);
                    method(wi.getClass(), "setRainTime", int.class).invoke(wi, 1000000);
                }
                System.out.println("[MoeHarness] weather " + s[1]);
                shot++;
                until = System.currentTimeMillis() + settleMs;
                return;
            }
            if (s[0].equals("@time")) {
                // @time t: world time in the server and client worlds (worldInfo.setWorldTime)
                long tm = Long.parseLong(s[1]);
                Object sw = null;
                try { sw = get(get(mc, "integratedServerRuntime"), "world"); } catch (Exception ex) { }
                for (Object lw : new Object[] {sw, w}) {
                    if (lw == null) continue;
                    Object wi = get(lw, "worldInfo");
                    method(wi.getClass(), "setWorldTime", long.class).invoke(wi, tm);
                }
                System.out.println("[MoeHarness] time " + tm);
                shot++;
                until = System.currentTimeMillis() + settleMs;
                return;
            }
            if (s[0].equals("@icons")) {
                // @icons: every legacy terrain slot that has a texture assigned, as the game has it now.
                Object re = get(mc, "renderEngine");
                Object tm = method(re.getClass(), "getRuntimeTextureManager").invoke(re);
                Object ir = get(tm, "iconRegistry");
                Method res = method(ir.getClass(), "getBlockResourceForIndex", int.class);
                StringBuilder used = new StringBuilder(), free = new StringBuilder();
                for (int i = 0; i < 256; i++) {
                    Object r = res.invoke(ir, i);
                    if (r != null) used.append(i).append('=').append(r).append(' '); else free.append(i).append(' ');
                }
                System.out.println("[MoeHarness] icons used: " + used);
                System.out.println("[MoeHarness] icons free: " + free);
                shot++;
                until = System.currentTimeMillis() + settleMs;
                return;
            }
            if (s[0].equals("@putc")) {
                // @putc x,y,z,id[,meta] ...: blocks set in the client world without neighbour updates, marked for re-render.
                Method sm = method(w.getClass(), "setBlockAndMetadata", int.class, int.class, int.class, int.class, int.class);
                Method mu = method(w.getClass(), "markBlockNeedsUpdate", int.class, int.class, int.class);
                for (int k = 1; k < s.length; k++) {
                    String[] p = s[k].split(",");
                    int bx = Integer.parseInt(p[0]), by = Integer.parseInt(p[1]), bz = Integer.parseInt(p[2]);
                    sm.invoke(w, bx, by, bz, Integer.parseInt(p[3]), p.length > 4 ? Integer.parseInt(p[4]) : 0);
                    mu.invoke(w, bx, by, bz);
                }
                System.out.println("[MoeHarness] @putc " + (s.length - 1) + " blocks in the client world");
                shot++;
                until = System.currentTimeMillis() + settleMs;
                return;
            }
            if (s[0].equals("@put")) {
                // @put x,y,z,id[,meta] ...: blocks set in the integrated server's world (sent on to the client).
                Object sw = null;
                try { sw = get(get(mc, "integratedServerRuntime"), "world"); } catch (Exception ex) { }
                Object tw = sw != null ? sw : w;
                if (snowAt != null && snowAt[2] < 0) {
                    Method id = method(w.getClass(), "getBlockId", int.class, int.class, int.class);
                    int y = 127;
                    while (y > 1 && ((Integer) id.invoke(w, snowAt[0], y, snowAt[1]) == 0 || (Integer) id.invoke(w, snowAt[0], y, snowAt[1]) == 78)) y--;
                    snowAt[2] = y;
                    System.out.println("[MoeHarness] ground at the snowy spot: y " + y);
                }
                Method sb = method(tw.getClass(), "setBlockWithNotify", int.class, int.class, int.class, int.class);
                Method sm = method(tw.getClass(), "setBlockMetadataWithNotify", int.class, int.class, int.class, int.class);
                for (int k = 1; k < s.length; k++) {
                    String[] p = s[k].split(",");
                    int bx = Integer.parseInt(p[0]), by = Integer.parseInt(p[1]), bz = Integer.parseInt(p[2]);
                    if (snowAt != null) { bx += snowAt[0]; by += snowAt[2]; bz += snowAt[1]; }
                    sb.invoke(tw, bx, by, bz, Integer.parseInt(p[3]));
                    if (p.length > 4) sm.invoke(tw, bx, by, bz, Integer.parseInt(p[4]));
                }
                System.out.println("[MoeHarness] @put " + (s.length - 1) + " blocks in the " + (sw != null ? "server" : "client") + " world");
                shot++;
                until = System.currentTimeMillis() + settleMs;
                return;
            }
            if (s[0].equals("@set")) {
                // @set x y z blockId: client-side setBlockWithNotify (e.g. a torch next to a test spot).
                method(w.getClass(), "setBlockWithNotify", int.class, int.class, int.class, int.class).invoke(w,
                    Integer.parseInt(s[1]), Integer.parseInt(s[2]), Integer.parseInt(s[3]), Integer.parseInt(s[4]));
                System.out.println("[MoeHarness] " + String.join(" ", s));
                shot++;
                until = System.currentTimeMillis() + settleMs;
                return;
            }
            if (s[0].equals("@opt")) {
                @SuppressWarnings("unchecked") Map<String, String> opts = (Map<String, String>) get(gs, "shaderPackOptions");
                opts.put(s[1], s[2]);
                spm.getMethod("publish", gs.getClass()).invoke(null, gs);
            } else if (s[0].equals("@shaders")) {
                spm.getMethod("toggleLighting", gs.getClass()).invoke(null, gs);
            }
            method(gs.getClass(), "saveOptions").invoke(gs);
            System.out.println("[MoeHarness] " + String.join(" ", s) + " -> lighting " + method(gs.getClass(), "resolveShaderLightingMode").invoke(gs)
                + ", revision " + spm.getMethod("revision").invoke(null));
            shot++;
            until = System.currentTimeMillis() + settleMs;
            return;
        }
        float yaw = Float.parseFloat(s[1]), pitch = Float.parseFloat(s[2]);
        double x = Double.parseDouble(s[3]), y = Double.parseDouble(s[4]), z = Double.parseDouble(s[5]);
        if (snowAt != null) { x += snowAt[0]; z += snowAt[1]; if (snowAt[2] >= 0) y += snowAt[2]; }
        for (String t : s)
            if (t.startsWith("hide=")) {
                // hide=cx0,cz0,cx1,cz1: those chunk columns are not drawn (every render pass set empty, each frame)
                String[] h = t.substring(5).split(",");
                int x0 = Integer.parseInt(h[0]) * 16, z0 = Integer.parseInt(h[1]) * 16, x1 = Integer.parseInt(h[2]) * 16, z1 = Integer.parseInt(h[3]) * 16;
                Object rg = get(mc, "renderGlobal");
                Method empty = null;
                for (String fn : new String[] {"worldRenderers", "sortedWorldRenderers"}) {
                    Object[] rs = (Object[]) get(rg, fn);
                    if (rs == null) continue;
                    for (Object r : rs) {
                        if (r == null) continue;
                        int rx = (Integer) get(r, "posX"), rz = (Integer) get(r, "posZ");
                        if (rx < x0 || rx > x1 || rz < z0 || rz > z1) continue;
                        if (empty == null) empty = method(r.getClass(), "setRenderPassEmpty", int.class, boolean.class);
                        for (int pass = 0; pass < 4; pass++) try { empty.invoke(r, pass, true); } catch (Exception ex) { }
                        set(r, "isVisible", Boolean.FALSE);
                    }
                }
            }
        if (waitShot != shot) {
            waitShot = shot;
            for (String t : s) if (t.startsWith("wait=")) until = System.currentTimeMillis() + Long.parseLong(t.substring(5));
        }
        method(pl.getClass(), "setPosition", double.class, double.class, double.class).invoke(pl, x, y, z);
        {
            // move the server's player too, so the world around the camera is loaded and random-ticked
            try {
                Object sw = get(get(mc, "integratedServerRuntime"), "world");
                for (Object sp : new ArrayList<Object>((List<?>) get(sw, "playerEntities")))
                    method(sp.getClass(), "setPosition", double.class, double.class, double.class).invoke(sp, x, y, z);
            } catch (Exception ex) { }
        }
        for (String f : new String[] {"prevPosX", "lastTickPosX"}) set(pl, f, x);
        for (String f : new String[] {"prevPosY", "lastTickPosY"}) set(pl, f, y);
        for (String f : new String[] {"prevPosZ", "lastTickPosZ"}) set(pl, f, z);
        for (String f : new String[] {"motionX", "motionY", "motionZ"}) set(pl, f, 0.0D);
        for (String f : new String[] {"rotationYaw", "prevRotationYaw"}) set(pl, f, yaw);
        for (String f : new String[] {"rotationPitch", "prevRotationPitch"}) set(pl, f, pitch);
        long nowNs = System.nanoTime();
        if (until - System.currentTimeMillis() < 1500 && fpsStart == 0) { fpsStart = nowNs; fpsFrames = 0; }
        if (fpsStart != 0) fpsFrames++;
        if (System.currentTimeMillis() < until) return;
        if (fpsStart != 0 && nowNs > fpsStart) System.out.println("[MoeHarness] fps " + s[0] + " " + (int) (fpsFrames * 1e9 / (nowNs - fpsStart)));
        fpsStart = 0;
        String drop = null;
        for (String t : s) if (t.startsWith("drop=")) drop = t.substring(5);
        if (drop != null) {
            String[] d = drop.split(",");
            if (dropLeft < 0) {
                // What the client sees when sand starts to fall: the block is still there and the falling
                // entity appears in the same cell (the server's block removal arrives a moment later).
                int bx = Integer.parseInt(d[0]), by = Integer.parseInt(d[1]), bz = Integer.parseInt(d[2]), id = Integer.parseInt(d[3]);
                if (d.length > 5 && d[5].equals("ahead")) {
                    // First air cell 2-6 blocks straight ahead of the camera (bx,by,bz ignored).
                    Method gb = method(w.getClass(), "getBlockId", int.class, int.class, int.class);
                    double yr = Math.toRadians(yaw);
                    for (int k = 2; k <= 6; k++) {
                        int cx = (int) Math.floor(x - Math.sin(yr) * k), cy = (int) Math.floor(y), cz = (int) Math.floor(z + Math.cos(yr) * k);
                        if ((Integer) gb.invoke(w, cx, cy, cz) == 0) { bx = cx; by = cy; bz = cz; break; }
                    }
                }
                Object sw = null;
                try { sw = get(get(mc, "integratedServerRuntime"), "world"); } catch (Exception ex) { }
                if (sw != null && !(d.length > 6 && d[6].equals("client"))) {
                    // The real thing: set the block in the integrated server's world; the server makes it fall
                    // and sends the falling block to the client.
                    int height = d.length > 7 ? Integer.parseInt(d[7]) : 1;
                    for (int k = 0; k < height; k++)
                        method(sw.getClass(), "setBlockWithNotify", int.class, int.class, int.class, int.class).invoke(sw, bx, by + k, bz, id);
                    System.out.println("[MoeHarness] block set in the server world");
                } else {
                    method(w.getClass(), "setBlockWithNotify", int.class, int.class, int.class, int.class).invoke(w, bx, by, bz, id);
                    Class<?> levelC = Class.forName("net.minecraft.world.level.Level");
                    Object fe = Class.forName("net.minecraft.src.entity.EntityFallingSand").getConstructor(levelC, double.class, double.class, double.class, int.class)
                        .newInstance(w, bx + 0.5, by + 0.5, bz + 0.5, id);
                    method(w.getClass(), "entityJoinedWorld", Class.forName("net.minecraft.world.entity.Entity")).invoke(w, fe);
                }
                dropLeft = Integer.parseInt(d[4]);
                dropN = 0;
                // stale: once a falling block's cell is air, put its sky light back to 0 for a few frames, the
                // out-of-date light M:OE's deferred light updates can leave there.
                dropStale = d.length > 8 && d[8].equals("stale");
                staleCount = 0;
                System.out.println("[MoeHarness] drop " + drop);
            }
            // Every frame is checked, but only frames with a falling block inside a solid cell (the flash) and
            // the first frame after are saved, so saving doesn't slow the game past the moment.
            int state = logFalling(w, dropN);
            if (state == 1 && dropStale && staleCount < 3) state = 3;  // keep going: stale light comes next frame
            if (state == 2 || (state == 1 && dropSawSolid && !dropSavedAfter)) {
                save(mc, String.format(Locale.ROOT, "%s_%02d%s", s[0], dropN, state == 2 ? "_solid" : "_after"));
                if (state == 2) dropSawSolid = true; else dropSavedAfter = true;
                dropLeft--;
            }
            dropN++;
            if (dropN < 4000 && dropLeft > 0 && !dropSavedAfter) return;
            if (!dropSawSolid) save(mc, s[0] + "_nosolid");
            dropLeft = -1;
            dropSawSolid = false;
            dropSavedAfter = false;
        } else {
            save(mc, s[0]);
        }
        shot++;
        until = System.currentTimeMillis() + settleMs;
        if (shot >= shots.size()) { System.out.println("[MoeHarness] done " + shot + " shots"); System.out.flush(); Runtime.getRuntime().halt(0); }
    }

    /** Each falling block: position, fall time, the cell M:OE samples its light from, and the lighting it is drawn with. */
    static int logFalling(Object w, int n) throws Exception {
        int state = 0;
        Class<?> fs = Class.forName("net.minecraft.src.entity.EntityFallingSand");
        Class<?> vl = Class.forName("net.minecraft.src.world.core.VisualLightmap");
        Object rm = Class.forName("net.minecraft.src.render.entity.RenderManager").getField("instance").get(null);
        for (Object e : new ArrayList<Object>((List<?>) get(w, "loadedEntityList"))) {
            if (!fs.isInstance(e)) continue;
            double px = (Double) get(e, "posX"), py = (Double) get(e, "posY"), pz = (Double) get(e, "posZ");
            Object bb = method(e.getClass(), "getBoundingBox").invoke(e);
            double h = (Double) get(bb, "maxY") - (Double) get(bb, "minY");
            int cx = (int) Math.floor(px), cy = (int) Math.floor(py - (Float) get(e, "yOffset") + h * 0.66), cz = (int) Math.floor(pz);
            int id = (Integer) method(w.getClass(), "getBlockId", int.class, int.class, int.class).invoke(w, cx, cy, cz);
            int packed = (Integer) method(w.getClass(), "getPackedWeatherLightComponents", int.class, int.class, int.class).invoke(w, cx, cy, cz);
            Object lit = method(rm.getClass(), "getEntityLightingForRender", Class.forName("net.minecraft.world.entity.Entity"), float.class).invoke(rm, e, 1.0F);
            boolean solid = (Boolean) method(w.getClass(), "isBlockOpaqueCube", int.class, int.class, int.class).invoke(w, cx, cy, cz);
            if (dropStale && !solid && staleCount < 3) {
                Class<?> esb = Class.forName("net.minecraft.src.world.core.EnumSkyBlock");
                @SuppressWarnings({"unchecked", "rawtypes"}) Object skyEnum = Enum.valueOf((Class) esb, "Sky");
                method(w.getClass(), "setLightValue", esb, int.class, int.class, int.class, int.class).invoke(w, skyEnum, cx, cy, cz, 0);
                staleCount++;
            }
            // Out-of-date light: darker than a neighbour minus one (the cell's block was just removed).
            int up = (Integer) method(w.getClass(), "getPackedWeatherLightComponents", int.class, int.class, int.class).invoke(w, cx, cy + 1, cz);
            int skyHere = (Integer) vl.getMethod("sky", int.class).invoke(null, packed), skyUp = (Integer) vl.getMethod("sky", int.class).invoke(null, up);
            solid |= skyHere < skyUp - 1;
            state = Math.max(state, solid ? 2 : 1);
            if (!solid && dropSavedAfter) continue;
            System.out.println(String.format(Locale.ROOT, "[MoeHarness] frame %02d falling id %s y %.3f fallTime %s cell %d,%d,%d block %d%s sky %s blk %s -> %s",
                n, get(e, "blockID"), py, get(e, "fallTime"), cx, cy, cz, id, solid ? " (solid/stale)" : "",
                vl.getMethod("sky", int.class).invoke(null, packed), vl.getMethod("block", int.class).invoke(null, packed), lit));
        }
        return state;
    }

    /** Keeps the test items still and unrotated so the two draws are comparable. */
    static void holdItems() throws Exception {
        for (int i = 0; i < heldItems.size(); i++) {
            Object it = heldItems.get(i);
            double[] p = heldPos.get(i);
            method(it.getClass(), "setPosition", double.class, double.class, double.class).invoke(it, p[0], p[1], p[2]);
            for (String f : new String[] {"prevPosX", "lastTickPosX"}) set(it, f, p[0]);
            for (String f : new String[] {"prevPosY", "lastTickPosY"}) set(it, f, p[1]);
            for (String f : new String[] {"prevPosZ", "lastTickPosZ"}) set(it, f, p[2]);
            for (String f : new String[] {"motionX", "motionY", "motionZ"}) set(it, f, 0.0D);
            set(it, "age", Integer.valueOf(0));
            set(it, "hoverStart", Float.valueOf(0.0F));
            for (String f : new String[] {"rotationYaw", "prevRotationYaw"}) set(it, f, Float.valueOf(0.0F));
        }
    }

    static void save(Object mc, String name) throws Exception {
        int w = (Integer) method(mc.getClass(), "getWindowFramebufferWidth").invoke(mc);
        int h = (Integer) method(mc.getClass(), "getWindowFramebufferHeight").invoke(mc);
        Class<?> rd = Class.forName("net.minecraft.src.graphics.api.RenderDevice");
        ByteBuffer buf = ByteBuffer.allocateDirect(w * h * 3).order(ByteOrder.nativeOrder());
        rd.getMethod("glPixelStorei", int.class, int.class).invoke(null, 3333, 1);
        rd.getMethod("glPixelStorei", int.class, int.class).invoke(null, 3317, 1);
        rd.getMethod("glReadPixels", int.class, int.class, int.class, int.class, int.class, int.class, ByteBuffer.class)
            .invoke(null, 0, 0, w, h, 6407, 5121, buf);
        BufferedImage img = new BufferedImage(w, h, BufferedImage.TYPE_INT_RGB);
        for (int yy = 0; yy < h; yy++) for (int xx = 0; xx < w; xx++) {
            int i = ((h - 1 - yy) * w + xx) * 3;
            img.setRGB(xx, yy, (buf.get(i) & 255) << 16 | (buf.get(i + 1) & 255) << 8 | (buf.get(i + 2) & 255));
        }
        ImageIO.write(img, "png", new File(outDir, name + ".png"));
        StringBuilder fog = new StringBuilder();
        try {
            Object er = get(mc, "entityRenderer");
            fog.append(String.format(Locale.ROOT, " fogColor %.4f %.4f %.4f far %.1f",
                ((Number) get(er, "fogColorRed")).floatValue(), ((Number) get(er, "fogColorGreen")).floatValue(),
                ((Number) get(er, "fogColorBlue")).floatValue(), ((Number) get(er, "farPlaneDistance")).floatValue()));
            Class<?> vf = Class.forName("net.minecraft.src.render.world.VoidFog");
            fog.append(String.format(Locale.ROOT, " voidDistance %.3f scale %.4f cave %.3f",
                find(vf, "voidDistance").getFloat(null), find(vf, "scale").getFloat(null), find(vf, "cave").getFloat(null)));
            Object v = method(Class.forName("net.minecraft.src.render.world.WarmlightSettings"), "current").invoke(null);
            fog.append(" fromPack ").append(get(v, "fromPack")).append(" warm ").append(get(v, "warm"))
                .append(" blue ").append(get(v, "blueNight")).append(" voidFog ").append(get(v, "voidFog"));
        } catch (Throwable t) {
            fog.append(" (no Warmlighting Final: ").append(t).append(")");
        }
        System.out.println("[MoeHarness] saved " + name + " " + w + "x" + h + fog);
    }
}
