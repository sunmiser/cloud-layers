#!/bin/bash
# run_moe.sh <merged M:OE jar> <outdir> <shots file> <world folder in $WORK/moeworlds> [extra -D...]
# Runs Minecraft Oldschool Edition (Vulkan) with MoeHarness. $WORK/moe-home is the game folder
# (options.txt, resources -> the instance's resources); the world is copied in fresh every run.
L=~/.local/share/PrismLauncher/libraries; LW=$L/org/lwjgl
JAR=$1; OUT=$2; SHOTS=$3; W=$4; shift 4
MH="$WORK/moe-home"; mkdir -p "$MH/saves"
rm -rf "$MH/saves/$W"; cp -r "$WORK/moeworlds/$W" "$MH/saves/$W"
CP="$WORK/agent.jar:$L/org/ow2/asm/asm/9.9/asm-9.9.jar"
for a in lwjgl lwjgl-freetype lwjgl-glfw lwjgl-jemalloc lwjgl-openal lwjgl-opengl lwjgl-sdl lwjgl-shaderc lwjgl-spvc lwjgl-stb lwjgl-vma lwjgl-vulkan; do
  CP="$CP:$LW/$a/3.4.3/$a-3.4.3.jar"
  [ -f "$LW/$a-natives-linux/3.4.3/$a-natives-linux-3.4.3.jar" ] && CP="$CP:$LW/$a-natives-linux/3.4.3/$a-natives-linux-3.4.3.jar"
done
[ -f "$LW/lwjgl-natives-linux/3.4.3/lwjgl-natives-linux-3.4.3.jar" ] && CP="$CP:$LW/lwjgl-natives-linux/3.4.3/lwjgl-natives-linux-3.4.3.jar"
cd "$MH"
exec ~/.local/share/PrismLauncher/java/eclipse_temurin_jre25.0.4+7/bin/java -Xmx4g --enable-native-access=ALL-UNNAMED \
  -Dminecraft.basedir="$MH" -Dver=moe -Dworld="$W" -Dshots="$SHOTS" -Dout="$OUT" "$@" \
  -javaagent:"$WORK/agent.jar" -cp "$CP:$JAR" net.minecraft.client.Minecraft HarnessPlayer -
