#!/bin/bash
# moecase.sh <name> <jar> <pack zip or -> <shaderPack id> <mode> <world> [packId/opt=value ...]
G=$(cd "$(dirname "$0")" && pwd)
N=$1; JAR=$2; PACK=$3; SP=$4; MODE=$5; W=$6; shift 6
MH="$WORK/moe-home"
cp "$WORK/moe-options.base" "$MH/options.txt"
rm -f "$MH/resourcepacks/"*.zip
[ "$PACK" != "-" ] && cp "$PACK" "$MH/resourcepacks/warmlighting_final_shaderpack_m-oe.zip"
PF=; [ "$PACK" != "-" ] && PF=warmlighting_final_shaderpack_m-oe.zip
PACKFILE=$PF python3 "$G/moeopts.py" "$MH/options.txt" "$SP" "$MODE" "$@"
mkdir -p "$WORK/outm"; rm -rf "$WORK/outm/$N"
timeout 240 "$G/run_moe.sh" "$JAR" "$WORK/outm/$N" "${SHOTS:-$WORK/shots-moe-cave.txt}" "$W" > "$WORK/outm/$N.log" 2>&1
echo "$N exit $? $(grep -c 'MoeHarness\] saved' "$WORK/outm/$N.log") shots"
