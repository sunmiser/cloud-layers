import java.awt.Frame;
import java.awt.image.BufferedImage;
import java.io.*;
import java.lang.reflect.*;
import java.nio.ByteBuffer;
import java.util.*;
import javax.imageio.ImageIO;
import org.lwjgl.BufferUtils;
import org.lwjgl.opengl.GL11;

/**
 * Drives the real alpha/beta client: loads a world, holds the camera at scripted angles and saves
 * the back buffer. Script from -Dshots=path, lines: name yaw pitch [time] [x y z] [fall=x,y,z,blockId].
 * fall= spawns a falling block (EntityFallingSand) centred there and holds it still until the shot is saved.
 * drop=x,y,z,blockId,frames sets that block with notify after settling (sand in the air starts to fall) and
 * saves the next `frames` frames in a row as name_NN.
 * put=x,y,z,id (any number per line) sets a block when the shot starts. Alpha: without neighbour updates and marked for
 * re-render. Beta: setBlockWithNotify. snow / clear (b1.7.3): keeps it raining/snowing, or dry. wait=ms: settle time for that shot.
 * -Dfindsnow (b1.7.3): shot x/z are relative to the nearest snowy biome (Taiga/Tundra/Ice Desert) found from the start.
 * hide=cx0,cz0,cx1,cz1: the chunk columns cx0..cx1, cz0..cz1 are not drawn during that shot (every section's skip
 * flags are set each frame), the "chunk that stopped rendering" bug.
 * Works on a1.1.2_01, b1.7.3 and b1.8.1 (-Dver=a11201|b173|b181); obfuscated names are in the table below.
 */
public class Harness {
    static int frame, phase, shot, wait, retries;
    static long until, fpsStart;
    static int fpsFrames;
    static List<String[]> shots = new ArrayList<String[]>();
    static File outDir = new File(System.getProperty("out", "out"));
    static String world = System.getProperty("world", "World2");
    static int settle = Integer.getInteger("settle", 40);
    static int firstSettle = Integer.getInteger("firstSettle", 400);
    static double[] hold;
    static Object fallEnt;
    static int dropLeft = -1, dropN;
    static boolean dropRun;
    static int fallShot = -1, putShot = -1;
    static int[] snowAt;
    // Obfuscated names per version: a1.1.2_01, b1.7.3, b1.8.1.
    static final String VER = System.getProperty("ver", "a11201");
    static final boolean BETA = !VER.equals("a11201");
    static final boolean B181 = VER.equals("b181");
    static String n(String alpha, String b173, String b181) { return B181 ? b181 : BETA ? b173 : alpha; }
    static final String M_WORLD = n("e", "f", "f"), M_PLAYER = n("g", "h", "h"), M_SCREEN = n("p", "r", "r"),
        M_W = n("c", "d", "d"), M_H = n("d", "e", "e"), M_RG = n("f", "g", "g"), M_PC = n("b", "c", "c"), PC_CLASS = n("ia", "os", "xu"),
        X = n("ak", "aM", "o"), Y = n("al", "aN", "p"), Z = n("am", "aO", "q"),
        PX = n("ah", "aJ", "l"), PY = n("ai", "aK", "m"), PZ = n("aj", "aL", "n"),
        LX = n("aI", "bl", "N"), LY = n("aJ", "bm", "O"), LZ = n("aK", "bn", "P"),
        MX = n("an", "aP", "r"), MY = n("ao", "aQ", "s"), MZ = n("ap", "aR", "t"),
        YAW = n("aq", "aS", "u"), PITCH = n("ar", "aT", "v"), PYAW = n("as", "aU", "w"), PPITCH = n("at", "aV", "x"),
        SETPOS = n("a", "e", "d");

    static Object get(Object o, String f) throws Exception { Field x = find(o.getClass(), f); return x.get(o); }
    static void set(Object o, String f, Object v) throws Exception { find(o.getClass(), f).set(o, v); }
    static Field find(Class<?> c, String f) throws Exception {
        for (Class<?> k = c; k != null; k = k.getSuperclass()) {
            try { Field x = k.getDeclaredField(f); x.setAccessible(true); return x; } catch (NoSuchFieldException e) { }
        }
        throw new NoSuchFieldException(c + "." + f);
    }

    public static void frame(Object mc) {
        try { step(mc); } catch (Throwable t) { t.printStackTrace(); System.exit(3); }
    }

    static void step(Object mc) throws Exception {
        frame++;
        if (phase == 0) {
            BufferedReader r = new BufferedReader(new FileReader(System.getProperty("shots")));
            for (String s; (s = r.readLine()) != null; ) { s = s.trim(); if (s.length() > 0 && !s.startsWith("#")) shots.add(s.split("\\s+")); }
            r.close();
            // A run with drops lets world time run throughout; holding it still piles up block updates.
            for (String[] sh : shots) for (String t : sh) if (t.startsWith("drop=")) dropRun = true;
            outDir.mkdirs();
            int w = Integer.getInteger("w", 1280), h = Integer.getInteger("h", 720);
            for (Frame f : Frame.getFrames()) {
                java.awt.Insets in = f.getInsets();
                f.setSize(w + in.left + in.right, h + in.top + in.bottom);
            }
            phase = 1;
            return;
        }
        if (phase == 1) {
            if (frame < 240) return;
            try {
                Method gd = mc.getClass().getSuperclass().getDeclaredMethod("b");

                File wd = new File(new File((File) gd.invoke(null), "saves"), world);
                System.out.println("[Harness] world dir " + wd.getAbsolutePath() + " exists=" + wd.exists());
                DataOutputStream o = new DataOutputStream(new FileOutputStream(new File(wd, "session.lock")));
                o.writeLong(1L); o.close();
            } catch (Throwable t) { t.printStackTrace(); }
            Class<?> mcc = mc.getClass().getSuperclass();
            Object pc = Class.forName(PC_CLASS).getConstructor(mcc).newInstance(mc);
            set(mc, M_PC, pc);
            Method m;
            Object[] args;
            if (B181) {
                Class<?> ws = Class.forName("dx");
                m = mcc.getDeclaredMethod("a", String.class, String.class, ws);
                args = new Object[] {world, world, ws.getConstructor(long.class, int.class, boolean.class).newInstance(0L, 0, false)};
            } else if (BETA) {
                m = mcc.getDeclaredMethod("a", String.class, String.class, long.class);
                args = new Object[] {world, world, 0L};
            } else {
                m = mcc.getDeclaredMethod("b", String.class);
                args = new Object[] {world};
            }
            m.setAccessible(true);
            try {
                m.invoke(mc, args);
            } catch (InvocationTargetException e) {
                System.out.println("[Harness] world load failed (" + e.getCause() + "), retrying");
                set(mc, M_WORLD, null);
                frame = 0;
                if (++retries > 8) System.exit(4);
                return;
            }
            phase = 2; wait = firstSettle; until = System.currentTimeMillis() + Long.getLong("firstSettleMs", 8000L);
            return;
        }
        Object world = get(mc, M_WORLD), pl = get(mc, M_PLAYER);
        if (world == null || pl == null) return;
        set(mc, M_SCREEN, null);
        if (hold == null) {
            hold = new double[] {(Double) get(pl, X), (Double) get(pl, Y), (Double) get(pl, Z)};
            String expect = System.getProperty("expectPos");
            if (expect != null) {
                String[] e = expect.split(",");
                if (Math.abs(hold[0] - Double.parseDouble(e[0])) > 2 || Math.abs(hold[2] - Double.parseDouble(e[1])) > 2) {
                    System.out.println("[Harness] WRONG WORLD: player at " + hold[0] + "," + hold[2]);
                    System.exit(5);
                }
            }
        }
        String[] s = shots.get(shot);
        float yaw = Float.parseFloat(s[1]), pitch = Float.parseFloat(s[2]);
        long time = s.length > 3 ? Long.parseLong(s[3]) : 6000L;
        double x = hold[0], y = hold[1], z = hold[2];
        if (s.length > 6) { x = Double.parseDouble(s[4]); y = Double.parseDouble(s[5]); z = Double.parseDouble(s[6]); }
        if (System.getProperty("findsnow") != null) {
            if (snowAt == null) snowAt = findSnow(world, (int) hold[0], (int) hold[2]);
            x += snowAt[0]; z += snowAt[1];
        }
        for (String t : s)
            if ((t.equals("snow") || t.equals("clear")) && BETA && !B181) {
                Object wi = get(world, "x");
                set(wi, "l", Boolean.valueOf(t.equals("snow")));
                set(wi, "m", Integer.valueOf(1000000));
            }
        // World time is held still for repeatable shots, except while a drop runs: block updates are
        // scheduled by world time, so sand would never start to fall.
        if (dropLeft >= 0 || dropRun) { }
        else if (B181) world.getClass().getMethod("a", long.class).invoke(world, Long.valueOf(time));
        else if (BETA) set(get(world, "x"), "e", Long.valueOf(time)); else set(world, "c", Long.valueOf(time));
        // Freeze cloud drift (RenderGlobal tick counter) so runs are pixel-comparable.
        Object rgl = get(mc, M_RG);
        if (rgl != null) set(rgl, "x", Integer.valueOf(Integer.getInteger("cloudTick", 1000)));
        for (String t : s)
            if (t.startsWith("hide=") && rgl != null) {
                String[] h = t.substring(5).split(",");
                int x0 = Integer.parseInt(h[0]) * 16, z0 = Integer.parseInt(h[1]) * 16, x1 = Integer.parseInt(h[2]) * 16, z1 = Integer.parseInt(h[3]) * 16;
                for (Field f : rgl.getClass().getDeclaredFields()) {
                    if (!f.getType().isArray() || f.getType().getComponentType().isPrimitive()) continue;
                    f.setAccessible(true);
                    Object[] rs = (Object[]) f.get(rgl);
                    if (rs == null) continue;
                    for (Object r : rs) {
                        if (r == null) continue;
                        Field pf;
                        try { pf = r.getClass().getField("p"); } catch (NoSuchFieldException ex) { break; }
                        if (pf.getType() != boolean[].class) break;
                        int rx = r.getClass().getField("c").getInt(r), rz = r.getClass().getField("e").getInt(r);
                        if (rx >= x0 && rx <= x1 && rz >= z0 && rz <= z1) { boolean[] sk = (boolean[]) pf.get(r); sk[0] = true; sk[1] = true; }
                    }
                }
            }
        Method sp = null;
        for (Class<?> k = pl.getClass(); sp == null && k != null; k = k.getSuperclass()) {
            try { sp = k.getDeclaredMethod(SETPOS, double.class, double.class, double.class); } catch (NoSuchMethodException e) { }
        }
        sp.setAccessible(true);
        sp.invoke(pl, x, y, z);
        // cavelog: print Warmlighting's cave fog blend (VoidFog.cave, 0 normal .. 1 cave gray) every frame of this shot
        for (String t : s)
            if (t.equals("cavelog")) {
                Class<?> vf = Class.forName("VoidFog");
                Field cf = vf.getDeclaredField("cave"), of = vf.getDeclaredField("open");
                cf.setAccessible(true); of.setAccessible(true);
                System.out.println("[Harness] cave " + s[0] + " " + System.currentTimeMillis() + " " + cf.getFloat(null) + " " + of.getFloat(null));
            }
        if (putShot != shot) {
            putShot = shot;
            for (String t : s) {
                if (t.startsWith("wait=")) until = System.currentTimeMillis() + Long.parseLong(t.substring(5));
                if (!t.startsWith("put=")) continue;
                if (B181) throw new IllegalStateException("put= is alpha/b1.7.3 only");
                String[] p = t.substring(4).split(",");
                int bx = Integer.parseInt(p[0]) + (snowAt != null ? snowAt[0] : 0), by = Integer.parseInt(p[1]);
                int bz = Integer.parseInt(p[2]) + (snowAt != null ? snowAt[1] : 0), id = Integer.parseInt(p[3]);
                if (BETA) {
                    world.getClass().getMethod("f", int.class, int.class, int.class, int.class).invoke(world, bx, by, bz, id);
                } else {
                    world.getClass().getMethod("a", int.class, int.class, int.class, int.class).invoke(world, bx, by, bz, id);
                    world.getClass().getMethod("h", int.class, int.class, int.class).invoke(world, bx, by, bz);
                }
            }
        }
        String fall = null;
        for (String t : s) if (t.startsWith("fall=")) fall = t.substring(5);
        if (fall != null) {
            String[] f = fall.split(",");
            double fx = Double.parseDouble(f[0]), fy = Double.parseDouble(f[1]), fz = Double.parseDouble(f[2]);
            if (fallShot != shot) {
                Class<?> fc = Class.forName(n("ff", "ju", "ju"));
                Constructor<?> k = BETA ? fc.getConstructor(Class.forName("fd"), double.class, double.class, double.class, int.class)
                    : fc.getConstructor(Class.forName("cn"), float.class, float.class, float.class, int.class);
                fallEnt = BETA ? k.newInstance(world, fx, fy, fz, Integer.parseInt(f[3]))
                    : k.newInstance(world, (float) fx, (float) fy, (float) fz, Integer.parseInt(f[3]));
                world.getClass().getMethod("a", Class.forName(BETA ? "sn" : "kh")).invoke(world, fallEnt);
                fallShot = shot;
            }
            Method esp = Class.forName(BETA ? "sn" : "kh").getDeclaredMethod(SETPOS, double.class, double.class, double.class);
            esp.setAccessible(true);
            esp.invoke(fallEnt, fx, fy, fz);
            for (String fn : new String[] {PX, LX}) set(fallEnt, fn, fx);
            for (String fn : new String[] {PY, LY}) set(fallEnt, fn, fy);
            for (String fn : new String[] {PZ, LZ}) set(fallEnt, fn, fz);
            for (String fn : new String[] {MX, MY, MZ}) set(fallEnt, fn, 0.0D);
            set(fallEnt, "b", Integer.valueOf(1));
        }
        for (String f : new String[] {PX, LX}) set(pl, f, x);
        for (String f : new String[] {PY, LY}) set(pl, f, y);
        for (String f : new String[] {PZ, LZ}) set(pl, f, z);
        for (String f : new String[] {MX, MY, MZ}) set(pl, f, 0.0D);
        set(pl, YAW, yaw); set(pl, PYAW, yaw);
        set(pl, PITCH, pitch); set(pl, PPITCH, pitch);
        long now = System.nanoTime();
        if (until - System.currentTimeMillis() < 1500 && fpsStart == 0) { fpsStart = now; fpsFrames = 0; }
        if (fpsStart != 0) fpsFrames++;
        if (wait-- > 0 || System.currentTimeMillis() < until) return;
        if (fpsStart != 0) System.out.println("[Harness] fps " + s[0] + " " + (int) (fpsFrames * 1e9 / (now - fpsStart)));
        fpsStart = 0;
        String drop = null;
        for (String t : s) if (t.startsWith("drop=")) drop = t.substring(5);
        if (drop != null) {
            String[] d = drop.split(",");
            if (dropLeft < 0) {
                world.getClass().getMethod(BETA ? "f" : "d", int.class, int.class, int.class, int.class).invoke(world,
                    Integer.parseInt(d[0]), Integer.parseInt(d[1]), Integer.parseInt(d[2]), Integer.parseInt(d[3]));
                dropLeft = Integer.parseInt(d[4]);
                dropN = 0;
                System.out.println("[Harness] drop " + drop);
                return;
            }
            int fallers = 0;
            Class<?> fsC = Class.forName(BETA ? "ju" : "ff");
            for (Class<?> k = world.getClass(); k != null; k = k.getSuperclass()) {
                for (Field f : k.getDeclaredFields()) {
                    if (!List.class.isAssignableFrom(f.getType()) || Modifier.isStatic(f.getModifiers())) continue;
                    f.setAccessible(true);
                    Object l = f.get(world);
                    if (l != null) for (Object o : new ArrayList<Object>((List<?>) l)) if (fsC.isInstance(o)) fallers++;
                }
            }
            int bid = (Integer) world.getClass().getMethod("a", int.class, int.class, int.class).invoke(world,
                Integer.parseInt(d[0]), Integer.parseInt(d[1]), Integer.parseInt(d[2]));
            System.out.println("[Harness] drop frame " + dropN + " world time " + (BETA ? get(get(world, "x"), "e") : get(world, "c"))
                + " block " + bid + " falling entities (in lists) " + fallers);
            save(mc, String.format(Locale.ROOT, "%s_%02d", s[0], dropN++));
            if (--dropLeft > 0) return;
            dropLeft = -1;
        } else {
            save(mc, s[0]);
        }
        if (fallEnt != null) {
            // Drop it below the world so it can't land in a later shot.
            Method esp = Class.forName(BETA ? "sn" : "kh").getDeclaredMethod(SETPOS, double.class, double.class, double.class);
            esp.setAccessible(true);
            esp.invoke(fallEnt, hold[0], -100.0, hold[2]);
            fallEnt = null;
        }
        shot++;
        wait = settle;
        until = System.currentTimeMillis() + Long.getLong("settleMs", 2500L);
        if (shot >= shots.size()) { System.out.println("[Harness] done " + shot + " shots"); System.exit(0); }
    }

    /** b1.7.3: the nearest column of a snowy biome (BiomeGenBase.getEnableSnow), searched on a 16-block grid. */
    static int[] findSnow(Object world, int x0, int z0) throws Exception {
        Object wcm = world.getClass().getMethod("a").invoke(world);
        Method at = wcm.getClass().getMethod("a", int.class, int.class);
        for (int r = 0; r <= 6000; r += 16)
            for (int dx = -r; dx <= r; dx += 16)
                for (int dz = -r; dz <= r; dz += 16) {
                    if (Math.max(Math.abs(dx), Math.abs(dz)) != r) continue;
                    int bx = x0 + dx, bz = z0 + dz;
                    if (bx > -64 && bx < 448 && bz > -64 && bz < 448) continue;   // the flat test map
                    Object b = at.invoke(wcm, bx, bz);
                    String want = System.getProperty("findsnow", "");
                    boolean name = want.length() == 0 || want.equals(b == null ? null : b.getClass().getField("n").get(b));
                    // a snowy biome all around (a 48-block square), so the view is inside it
                    boolean all = true;
                    for (int ox = -48; ox <= 48 && all; ox += 16) for (int oz = -48; oz <= 48 && all; oz += 16) {
                        Object c = at.invoke(wcm, bx + ox, bz + oz);
                        all = c != null && (Boolean) c.getClass().getMethod("c").invoke(c);
                    }
                    if (b != null && name && all) {
                        System.out.println("[Harness] snowy biome " + b.getClass().getField("n").get(b) + " at " + (x0 + dx) + "," + (z0 + dz));
                        return new int[] {x0 + dx, z0 + dz};
                    }
                }
        throw new IllegalStateException("no snowy biome within 3000 blocks");
    }

    /** GL fog state left by the frame that is being saved (its last setupFog). */
    static void logFog(String name) {
        java.nio.FloatBuffer f = BufferUtils.createFloatBuffer(16);
        GL11.glGetFloat(GL11.GL_FOG_START, f); float start = f.get(0);
        GL11.glGetFloat(GL11.GL_FOG_END, f); float end = f.get(0);
        GL11.glGetFloat(GL11.GL_FOG_COLOR, f); float r = f.get(0), g = f.get(1), b = f.get(2);
        GL11.glGetFloat(GL11.GL_COLOR_CLEAR_VALUE, f); float cr = f.get(0), cg = f.get(1), cb = f.get(2);
        System.out.println(String.format(java.util.Locale.ROOT, "[Harness] fog %s start %.3f end %.3f color %.4f %.4f %.4f clear %.4f %.4f %.4f",
            name, start, end, r, g, b, cr, cg, cb));
    }

    static void save(Object mc, String name) throws Exception {
        logFog(name);
        int w = (Integer) get(mc, M_W), h = (Integer) get(mc, M_H);
        ByteBuffer buf = BufferUtils.createByteBuffer(w * h * 3);
        GL11.glPixelStorei(GL11.GL_PACK_ALIGNMENT, 1);
        GL11.glReadBuffer(GL11.GL_BACK);
        GL11.glReadPixels(0, 0, w, h, GL11.GL_RGB, GL11.GL_UNSIGNED_BYTE, buf);
        BufferedImage img = new BufferedImage(w, h, BufferedImage.TYPE_INT_RGB);
        for (int yy = 0; yy < h; yy++) for (int xx = 0; xx < w; xx++) {
            int i = ((h - 1 - yy) * w + xx) * 3;
            img.setRGB(xx, yy, (buf.get(i) & 255) << 16 | (buf.get(i + 1) & 255) << 8 | (buf.get(i + 2) & 255));
        }
        ImageIO.write(img, "png", new File(outDir, name + ".png"));
        System.out.println("[Harness] saved " + name + " " + w + "x" + h);
    }
}
