#!/bin/bash
# runok.sh <ver> <jar> <outdir> <shots> [...]  (retries up to 4 times on a bad start)
H=$(cd "$(dirname "$0")" && pwd)
for t in 1 2 3 4; do
  rm -rf "$3"
  timeout 300 "$H/run.sh" "$@" > "$3.log" 2>&1
  c=$?
  if [ $c -eq 0 ] && grep -q "done" "$3.log"; then echo "ok $(basename "$3") (try $t)"; exit 0; fi
  echo "retry $(basename "$3") exit $c"
done
exit 1
