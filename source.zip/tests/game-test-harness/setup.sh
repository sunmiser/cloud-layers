#!/bin/bash
# setup.sh: builds $WORK/agent.jar, unpacks LWJGL natives, generates the void fog test worlds and copies
# the Lighting Test worlds (~/Downloads/lightingtest, made by lightingtest/source/gen.py).
set -e
H=$(cd "$(dirname "$0")" && pwd); L=~/.local/share/PrismLauncher/libraries
mkdir -p "$WORK/agentsrc" "$WORK/natives" "$WORK/worlds"
CP="$L/org/ow2/asm/asm/9.9/asm-9.9.jar:$L/org/lwjgl/lwjgl/lwjgl/2.9.4-nightly-20150209/lwjgl-2.9.4-nightly-20150209.jar"
javac -nowarn -source 1.8 -target 1.8 -d "$WORK/agentsrc" -cp "$CP" "$H"/Agent.java "$H"/Harness.java "$H"/HarnessMain.java
printf 'Premain-Class: Agent\n' > "$WORK/manifest.txt"
(cd "$WORK/agentsrc" && jar cfm "$WORK/agent.jar" "$WORK/manifest.txt" *.class)
(cd "$WORK/natives" && jar xf "$L/org/lwjgl/lwjgl/lwjgl-platform/2.9.4-nightly-20150209/lwjgl-platform-2.9.4-nightly-20150209-natives-linux.jar")
python3 "$H/../tests/voidworld.py" beta "$WORK/worlds/Void Fog Test b173" "Void Fog Test b173"
python3 "$H/../tests/voidworld.py" alpha "$WORK/worlds/World3"
cp -r ~/Downloads/lightingtest/"Lighting Test Map b173" "$WORK/worlds/"
cp -r ~/Downloads/lightingtest/World2 "$WORK/worlds/"
