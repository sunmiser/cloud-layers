import sys, zipfile
# mkjar.py out.jar base.jar [--drop prefix]... [--put name=file]... [--from jar]...
out, base = sys.argv[1], sys.argv[2]
drops, puts, froms = [], {}, []
a = sys.argv[3:]
i = 0
while i < len(a):
    if a[i] == '--drop': drops.append(a[i+1])
    elif a[i] == '--put': n, f = a[i+1].split('=', 1); puts[n] = open(f, 'rb').read()
    elif a[i] == '--from':
        with zipfile.ZipFile(a[i+1]) as z:
            for n in z.namelist():
                if not n.endswith('/') and not n.startswith('META-INF/'): puts[n] = z.read(n)
    i += 2
with zipfile.ZipFile(base) as zb, zipfile.ZipFile(out, 'w', zipfile.ZIP_DEFLATED) as zo:
    for n in zb.namelist():
        if n in puts or any(n.startswith(d) for d in drops): continue
        zo.writestr(n, zb.read(n))
    for n, b in puts.items():
        if not any(n.startswith(d) for d in drops): zo.writestr(n, b)
