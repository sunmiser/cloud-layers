import java.lang.instrument.ClassFileTransformer;
import java.lang.instrument.Instrumentation;
import java.security.ProtectionDomain;
import org.objectweb.asm.*;

/** Test-only agent: no mouse grab/mouse look, window always "active", and a per-frame hook. */
public class Agent {
    static final boolean B181 = "b181".equals(System.getProperty("ver"));
    static final boolean MOE = "moe".equals(System.getProperty("ver"));
    static final boolean NO_VOID_PARTICLES = Boolean.getBoolean("noVoidParticles");
    static final boolean NO_DISPLAY_TICKS = Boolean.getBoolean("noDisplayTicks");
    static final boolean NO_TEXTURE_ANIM = Boolean.getBoolean("noTextureAnim");
    static final boolean PIN_PARTIAL = Boolean.getBoolean("pinPartialTicks");
    public static void premain(String args, Instrumentation inst) {
        inst.addTransformer(new ClassFileTransformer() {
            public byte[] transform(ClassLoader l, String name, Class<?> c, ProtectionDomain d, byte[] b) {
                if (name == null || name.startsWith("java/") || name.startsWith("sun/") || name.startsWith("jdk/")
                        || name.startsWith("org/") || name.startsWith("com/") || name.startsWith("javax/")
                        || name.startsWith("Harness") || name.startsWith("MoeHarness") || name.equals("Agent")) return null;
                // M:OE has ~35000 classes; only its Minecraft class needs the hooks.
                if (MOE && !name.equals("net/minecraft/client/Minecraft")) return null;
                try {
                    final boolean[] changed = {false};
                    final boolean isMc = name.equals("net/minecraft/client/Minecraft");
                    ClassReader cr = new ClassReader(b);
                    ClassWriter cw = new ClassWriter(cr, ClassWriter.COMPUTE_MAXS);
                    cr.accept(new ClassVisitor(Opcodes.ASM9, cw) {
                        public MethodVisitor visitMethod(int acc, final String mn, String desc, String sig, String[] ex) {
                            // -DnoDisplayTicks: World.randomDisplayUpdates does nothing (no random torch smoke,
                            // flames or vanilla void particles), so runs can be pixel-compared.
                            if (NO_DISPLAY_TICKS && desc.equals("(III)V") && (name.equals("fd") && mn.equals("q")
                                    || name.equals("cn") && mn.equals("m") || name.equals("rv") && mn.equals("q"))) {
                                MethodVisitor mv = super.visitMethod(acc, mn, desc, sig, ex);
                                mv.visitCode();
                                mv.visitInsn(Opcodes.RETURN);
                                mv.visitMaxs(0, 0);
                                mv.visitEnd();
                                changed[0] = true;
                                return null;
                            }
                            final boolean run = isMc && mn.equals("run") && desc.equals("()V");
                            // -DpinPartialTicks: Timer.updateTimer (b173 py.a, a1.1.2_01 ir.a) always leaves
                            // renderPartialTicks at 0, so clouds, sky and interpolation are the same every run.
                            final boolean timer = PIN_PARTIAL && mn.equals("a") && desc.equals("()V")
                                && name.equals("b173".equals(System.getProperty("ver")) ? "py" : B181 ? "-" : "ir");
                            return new MethodVisitor(Opcodes.ASM9, super.visitMethod(acc, mn, desc, sig, ex)) {
                                public void visitInsn(int op) {
                                    if (timer && op == Opcodes.RETURN) {
                                        super.visitVarInsn(Opcodes.ALOAD, 0);
                                        super.visitInsn(Opcodes.FCONST_0);
                                        super.visitFieldInsn(Opcodes.PUTFIELD, name, "c", "F");
                                        changed[0] = true;
                                    }
                                    super.visitInsn(op);
                                }
                                public void visitLdcInsn(Object v) {
                                    // b1.8.1 World (rv): drop the vanilla void particles when asked, so fog shots can be pixel-compared.
                                    if (NO_VOID_PARTICLES && name.equals("rv") && "depthsuspend".equals(v)) { super.visitLdcInsn("voidfog-test-none"); changed[0] = true; return; }
                                    if (!B181 && !MOE && "Failed to check session lock, aborting".equals(v) && mn.equals("<init>")) {
                                        super.visitVarInsn(Opcodes.ALOAD, 5);
                                        super.visitMethodInsn(Opcodes.INVOKEVIRTUAL, "java/lang/Throwable", "printStackTrace", "()V", false);
                                        changed[0] = true;
                                    }
                                    super.visitLdcInsn(v);
                                }
                                public void visitMethodInsn(int op, String owner, String m, String ds, boolean itf) {
                                    // -DnoTextureAnim: Minecraft never calls RenderEngine.updateDynamicTextures (b173 ji.a,
                                    // a1.1.2_01 ey.a), so lava, water and fire keep their still terrain.png tiles.
                                    if (NO_TEXTURE_ANIM && isMc && op == Opcodes.INVOKEVIRTUAL && m.equals("a") && ds.equals("()V")
                                            && owner.equals(B181 ? "-" : "b173".equals(System.getProperty("ver")) ? "ji" : "ey")) {
                                        super.visitInsn(Opcodes.POP); changed[0] = true; return;
                                    }
                                    if (op == Opcodes.INVOKESTATIC && owner.equals("org/lwjgl/input/Mouse")) {
                                        if (m.equals("setGrabbed")) { super.visitInsn(Opcodes.POP); changed[0] = true; return; }
                                        if (m.equals("getDX") || m.equals("getDY")) { super.visitInsn(Opcodes.ICONST_0); changed[0] = true; return; }
                                    }
                                    if (op == Opcodes.INVOKESTATIC && owner.equals("org/lwjgl/opengl/Display") && m.equals("isActive")) {
                                        super.visitInsn(Opcodes.ICONST_1); changed[0] = true; return;
                                    }
                                    if (MOE && run && op == Opcodes.INVOKESTATIC && owner.equals("org/lwjgl/opengl/Display") && m.equals("swapBuffers") && ds.equals("()V")) {
                                        super.visitVarInsn(Opcodes.ALOAD, 0);
                                        super.visitMethodInsn(Opcodes.INVOKESTATIC, "MoeHarness", "frame", "(Ljava/lang/Object;)V", false);
                                        changed[0] = true;
                                    }
                                    if (run && op == Opcodes.INVOKESTATIC && owner.equals("org/lwjgl/opengl/Display") && m.equals("update") && ds.equals("()V")) {
                                        super.visitVarInsn(Opcodes.ALOAD, 0);
                                        super.visitMethodInsn(Opcodes.INVOKESTATIC, "Harness", "frame", "(Ljava/lang/Object;)V", false);
                                        changed[0] = true;
                                    }
                                    super.visitMethodInsn(op, owner, m, ds, itf);
                                }
                            };
                        }
                    }, 0);
                    return changed[0] ? cw.toByteArray() : null;
                } catch (Throwable t) {
                    t.printStackTrace();
                    return null;
                }
            }
        });
    }
}
