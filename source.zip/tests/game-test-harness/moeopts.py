"""moeopts.py <options.txt> <shaderPack id> <mode off|rasterized> [packId/option=value ...]
Sets M:OE's selected shader pack, shader lighting mode and shader pack option values in options.txt.
With PACKFILE=<zip name> in the environment that pack is also enabled as a resource pack (M:OE only
offers shader packs from enabled resource packs)."""
import json, os, sys
path, pack, mode = sys.argv[1:4]
lines = open(path).read().splitlines()
out = []
for l in lines:
    if l.startswith('shaderPack:'): l = 'shaderPack:' + pack
    elif l.startswith('shaderLightingMode:'): l = 'shaderLightingMode:' + mode
    elif l.startswith('resourcePacks:') and os.environ.get('PACKFILE'): l = 'resourcePacks:' + json.dumps([os.environ['PACKFILE']])
    elif l.startswith('skin:') and os.environ.get('PACKFILE'): l = 'skin:' + os.environ['PACKFILE']
    elif l.startswith('shaderPackOptions:'):
        opts = json.loads(l[len('shaderPackOptions:'):])
        for kv in sys.argv[4:]:
            k, v = kv.split('=', 1); opts[k] = v
        l = 'shaderPackOptions:' + json.dumps(opts, separators=(',', ':'))
    out.append(l)
open(path, 'w').write('\n'.join(out) + '\n')
