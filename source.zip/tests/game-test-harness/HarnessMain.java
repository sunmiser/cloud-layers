import java.io.File;
import java.lang.reflect.Field;

/** Sets the game directory the way Prism's legacy launcher does, then starts the client. */
public class HarnessMain {
    public static void main(String[] a) throws Exception {
        Class<?> mc = Class.forName("net.minecraft.client.Minecraft");
        File dir = new File(System.getProperty("user.home"), ".minecraft");
        for (Field f : mc.getDeclaredFields()) {
            if (f.getType() == File.class && java.lang.reflect.Modifier.isStatic(f.getModifiers())) {
                f.setAccessible(true);
                f.set(null, dir);
            }
        }
        mc.getMethod("main", String[].class).invoke(null, (Object) a);
    }
}
