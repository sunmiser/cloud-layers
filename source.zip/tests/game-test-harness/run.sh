#!/bin/bash
# run.sh <a11201|b173|b181> <merged game jar> <outdir> <shots file> [extra -D...]
# Needs $WORK with agent.jar, natives/ and worlds/ (see setup.sh). WORLD = save folder name under $WORK/worlds,
# EXPECT = "x,z" the player must load at.
L=~/.local/share/PrismLauncher/libraries
VER=$1; JAR=$2; OUT=$3; SHOTS=$4; shift 4
HM="$WORK/home-$VER"; mkdir -p "$HM/.minecraft/saves"
O="$HM/.minecraft/options.txt"
[ -f "$O" ] || printf 'music:0.0\nsound:0.0\nviewDistance:0\nfancyGraphics:true\n' > "$O"
grep -q "^difficulty:" "$O" || echo "difficulty:0" >> "$O"
sed -i -e "s/^viewDistance:.*/viewDistance:${VD:-0}/" -e "s/^fancyGraphics:.*/fancyGraphics:${FANCY:-true}/" -e "s/^difficulty:.*/difficulty:0/" "$O"
# Alpha needs the legacy merge sort (Prism passes it too) or its chunk sorter can crash on Java 8.
[ $VER = a11201 ] && set -- -Djava.util.Arrays.useLegacyMergeSort=true "$@"
W=${WORLD:?set WORLD}
rm -rf "$HM/.minecraft/saves/$W"; cp -r "$WORK/worlds/$W" "$HM/.minecraft/saves/$W"
exec ~/.local/share/PrismLauncher/java/eclipse_temurin_jre8.0.504+1/bin/java -Xmx2g -Duser.home="$HM" \
  -Djava.library.path="$WORK/natives" -Dver=$VER -Dworld="$W" -DexpectPos=${EXPECT:?set EXPECT} \
  -javaagent:"$WORK/agent.jar" -Dshots="$SHOTS" -Dout="$OUT" "$@" \
  -cp "$WORK/agent.jar:$L/org/ow2/asm/asm/9.9/asm-9.9.jar:$L/net/java/jinput/jinput/2.0.5/jinput-2.0.5.jar:$L/net/java/jutils/jutils/1.0.0/jutils-1.0.0.jar:$L/org/lwjgl/lwjgl/lwjgl/2.9.4-nightly-20150209/lwjgl-2.9.4-nightly-20150209.jar:$L/org/lwjgl/lwjgl/lwjgl_util/2.9.4-nightly-20150209/lwjgl_util-2.9.4-nightly-20150209.jar:$JAR" \
  HarnessMain HarnessPlayer -
