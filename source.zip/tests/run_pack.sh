#!/bin/bash
# Real-game test that layers 2 and 3 follow the cloud texture of the pack in use: noon, looking up 45 degrees, with only
# layer 2 drawn (as 3D) and only layer 3 drawn (flat), without and with a pack that has its own clouds.png.
# Beta: a texture pack (Vintage_beta173.zip from ~/Downloads); M:OE: a resource pack (Vintage_beta173_release.zip from
# the instance). The pack shots must differ from the no-pack shots, and look like the pack's clouds.
#   WORK=<harness work dir> ./run_pack.sh <b173|moe> <outdir> <cloudlayers zip> [pack zip]
set -e
V=$1; OUT=$2; ZIP=$3; T=$(cd "$(dirname "$0")" && pwd); H=$T/game-test-harness; mkdir -p "$OUT"
L=~/.local/share/PrismLauncher/libraries; P=~/.local/share/PrismLauncher/instances
if [ $V = b173 ]; then I=$P/b1.7.3; MC=$L/com/mojang/minecraft/b1.7.3/minecraft-b1.7.3-client.jar; PACK=${4:-$HOME/Downloads/Vintage_beta173.zip}
else I=$P/Minecraft.-.Oldschool.Edition; MC=$L/com/mojang/minecraft/b1.7.3/minecraft-b1.7.3-client.jar; PACK=${4:-$I/minecraft/resourcepacks/Vintage_beta173_release.zip}; fi
mods() { python3 - "$I/mmc-pack.json" <<'PY'
import json, sys
for c in json.load(open(sys.argv[1]))['components']:
    u = c['uid']
    if u.startswith('custom.jarmod.') and not c.get('disabled'): print(u[len('custom.jarmod.'):])
PY
}
for layer in 2 3; do
  E="layer1.alpha=0;layer2.alpha=0;layer3.alpha=0;layer$layer.alpha=0.8"
  python3 - "$ZIP" "$OUT/l$layer.zip" "$E" <<'PY'
import sys, zipfile, re
src, out, edits = sys.argv[1:]
with zipfile.ZipFile(src) as a, zipfile.ZipFile(out, 'w', zipfile.ZIP_DEFLATED) as b:
    for n in a.namelist():
        d = a.read(n)
        if n == 'cloudlayers_settings.txt':
            s = d.decode()
            for kv in filter(None, edits.split(';')):
                k, val = kv.split('=', 1); s = re.sub(r'(?m)^' + re.escape(k) + r'=.*$', k + '=' + val, s)
            d = s.encode()
        b.writestr(n, d)
PY
  args=(); for m in $(mods); do unzip -l "$I/jarmods/$m.jar" | grep -q "CloudLayers.class" || args+=(--from "$I/jarmods/$m.jar"); done
  python3 "$H/mkjar.py" "$OUT/l$layer.jar" "$MC" --drop META-INF/ "${args[@]}" --from "$OUT/l$layer.zip"
  for pk in none pack; do
    run="l$layer-$pk"
    if [ $V = b173 ]; then
      HM="$WORK/home-b173/.minecraft"; mkdir -p "$HM/texturepacks"; rm -f "$HM/texturepacks/"*.zip
      O="$HM/options.txt"; touch "$O"; sed -i '/^skin:/d' "$O"
      if [ $pk = pack ]; then cp "$PACK" "$HM/texturepacks/"; echo "skin:$(basename "$PACK")" >> "$O"; else echo "skin:Default" >> "$O"; fi
      echo "up 0 -45 6000 171.5 80 164.5" > "$OUT/$run.txt"
      WORLD="Leaf Test b173" EXPECT=171,164 FANCY=true TIMEOUT=300 "$H/runok.sh" b173 "$OUT/l$layer.jar" "$OUT/$run" "$OUT/$run.txt" -DsettleMs=4000 -DnoDisplayTicks
    else
      printf 'load 0 -45 280 100 300 wait=35000\n@time 6000\nup 0 -45 280 100 300 wait=4000\n' > "$OUT/$run.txt"
      cp "$WORK/moe-options.base" "$WORK/moe-home/options.txt"; rm -f "$WORK/moe-home/resourcepacks/"*.zip
      if [ $pk = pack ]; then cp "$PACK" "$WORK/moe-home/resourcepacks/"; sed -i "s/^resourcePacks:.*/resourcePacks:[\"$(basename "$PACK")\"]/" "$WORK/moe-home/options.txt"
      else sed -i 's/^resourcePacks:.*/resourcePacks:[]/' "$WORK/moe-home/options.txt"; fi
      timeout 400 "$H/run_moe.sh" "$OUT/l$layer.jar" "$OUT/$run" "$OUT/$run.txt" "Cave Mine Test Map MOE" > "$OUT/$run.log" 2>&1 || true
      echo "$run: $(grep -c 'MoeHarness\] saved' "$OUT/$run.log") shots, $(grep -c 'Exception' "$OUT/$run.log") exceptions"
    fi
  done
  rm -f "$OUT/l$layer.jar"
done
