#!/bin/bash
# Real-game look test: Cloud Layers zips side by side in one game version, with the instance's other jar mods.
# Shots: noon looking up 45 degrees and along the horizon, sunset (west) and night, each with alt_clouds off and on;
# Graphics Fast at noon. Alpha: copy of World1; Beta: copy of the Lighting Test map; M:OE: the Cave Mine map copy.
#   WORK=<harness work dir> ./run_compare.sh <a11201|b173|moe> <outdir> <name=zip>...
# Settings variants are made by editing cloudlayers_settings.txt (or the older cloudlayers/cloudlayers.properties).
set -e
V=$1; OUT=$2; shift 2; T=$(cd "$(dirname "$0")" && pwd); H=$T/game-test-harness; mkdir -p "$OUT"
L=~/.local/share/PrismLauncher/libraries; P=~/.local/share/PrismLauncher/instances
case $V in
  a11201) I=$P/a1.1.2_01; MC=$L/com/mojang/minecraft/a1.1.2_01/minecraft-a1.1.2_01-client.jar; W=World1; E=-354,-23; POS="-354.4 90.6 -23.5";;
  b173) I=$P/b1.7.3; MC=$L/com/mojang/minecraft/b1.7.3/minecraft-b1.7.3-client.jar; W="Leaf Test b173"; E=171,164; POS="171.5 80 164.5";;
  moe) I=$P/Minecraft.-.Oldschool.Edition; MC=$L/com/mojang/minecraft/b1.7.3/minecraft-b1.7.3-client.jar; POS="280 100 300";;
esac
mods() { python3 - "$I/mmc-pack.json" <<'PY'
import json, sys
for c in json.load(open(sys.argv[1]))['components']:
    u = c['uid']
    if u.startswith('custom.jarmod.') and not c.get('disabled'): print(u[len('custom.jarmod.'):])
PY
}
variant() {  # variant <zip> <out zip> <key=value;...>
  python3 - "$1" "$2" "$3" <<'PY'
import sys, zipfile, re
src, out, edits = sys.argv[1:]
with zipfile.ZipFile(src) as a, zipfile.ZipFile(out, 'w', zipfile.ZIP_DEFLATED) as b:
    for n in a.namelist():
        d = a.read(n)
        if n in ('cloudlayers_settings.txt', 'cloudlayers/cloudlayers.properties'):
            s = d.decode()
            for kv in filter(None, edits.split(';')):
                k, val = kv.split('=', 1); s = re.sub(r'(?m)^' + re.escape(k) + r'=.*$', k + '=' + val, s)
            d = s.encode()
        b.writestr(n, d)
PY
}
# shots: name yaw pitch time (alpha/beta also position; M:OE sets time with @time)
SHOTS=${SHOTS:-"noonup:0:-45:6000 noon:0:-5:6000 sunset:90:-8:12300 night:0:-30:18000"}  # EXTRA = more -D options for the game
for spec in "$@"; do
  name=${spec%%=*}; zip=${spec#*=}
  for alt in ${ALTS:-false true}; do
    variant "$zip" "$OUT/$name-$alt.zip" "alt_clouds=$alt"
    args=(); for m in $(mods); do unzip -l "$I/jarmods/$m.jar" | grep -q "CloudLayers.class" || args+=(--from "$I/jarmods/$m.jar"); done
    python3 "$H/mkjar.py" "$OUT/$name-$alt.jar" "$MC" --drop META-INF/ "${args[@]}" --from "$OUT/$name-$alt.zip"
    for gfx in ${GFX:-fancy fast}; do
      [ $gfx = fast ] && [ $alt = true ] && continue
      run="$name-$alt-$gfx"; : > "$OUT/$run.txt"
      if [ $V = moe ]; then
        echo "load 0 -5 $POS wait=35000" >> "$OUT/$run.txt"
        for s in $SHOTS; do IFS=: read -r n y p t <<< "$s"; [ $gfx = fast ] && [ $n != noonup ] && continue
          echo "@time $t" >> "$OUT/$run.txt"; echo "$n $y $p $POS wait=6000" >> "$OUT/$run.txt"; done
        cp "$WORK/moe-options.base" "$WORK/moe-home/options.txt"; rm -f "$WORK/moe-home/resourcepacks/"*.zip
        sed -i "s/^fancyGraphics:.*/fancyGraphics:$([ $gfx = fancy ] && echo true || echo false)/; s/^resourcePacks:.*/resourcePacks:[]/" "$WORK/moe-home/options.txt"
        timeout 600 "$H/run_moe.sh" "$OUT/$name-$alt.jar" "$OUT/$run" "$OUT/$run.txt" "Cave Mine Test Map MOE" $EXTRA > "$OUT/$run.log" 2>&1 || true
        echo "$run: $(grep -c 'MoeHarness\] saved' "$OUT/$run.log") shots, $(grep -c 'Exception' "$OUT/$run.log") exceptions"
      else
        for s in $SHOTS; do IFS=: read -r n y p t <<< "$s"; [ $gfx = fast ] && [ $n != noonup ] && continue
          echo "$n $y $p $t $POS" >> "$OUT/$run.txt"; done
        WORLD="$W" EXPECT=$E FANCY=$([ $gfx = fancy ] && echo true || echo false) TIMEOUT=300 "$H/runok.sh" $V "$OUT/$name-$alt.jar" "$OUT/$run" "$OUT/$run.txt" -DsettleMs=3000 -DnoTextureAnim -DpinPartialTicks -DnoDisplayTicks $EXTRA
      fi
    done
    rm -f "$OUT/$name-$alt.jar"
  done
done
