"""diff.py <outdir of run_compare.sh> <name A> <name B>: pixels differing by more than 24 (of 255) between the same
shots of two zips, for alt_clouds off and on and Graphics Fast, plus the mean colour change."""
import os, sys
from PIL import Image, ImageChops, ImageStat
out, a, b = sys.argv[1:]
for run in ('false-fancy', 'false-fast', 'true-fancy'):
    da, db = os.path.join(out, a + '-' + run), os.path.join(out, b + '-' + run)
    if not os.path.isdir(da) or not os.path.isdir(db): continue
    for f in sorted(os.listdir(da)):
        if not f.endswith('.png') or not os.path.exists(os.path.join(db, f)): continue
        ia, ib = Image.open(os.path.join(da, f)).convert('RGB'), Image.open(os.path.join(db, f)).convert('RGB')
        d = ImageChops.difference(ia, ib)
        n = sum(1 for v in d.convert('L').point(lambda v: 255 if v > 24 else 0).getdata() if v)
        ma, mb = ImageStat.Stat(ia).mean, ImageStat.Stat(ib).mean
        print('%-12s %-9s pixels>24: %6d   mean %s -> %s' % (run, f[:-4], n, ' '.join('%.1f' % v for v in ma), ' '.join('%.1f' % v for v in mb)))
