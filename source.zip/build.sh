#!/bin/bash
# Builds Cloud Layers into the folder above this one:
#   cloudlayers_a11201.zip (Alpha 1.1.2_01), cloudlayers_b173.zip (Beta 1.7.3), cloudlayers_m:oe.zip (Oldschool Edition)
#   ./build.sh [a11201] [b173] [moe]      (no argument: all three)
# Every zip is built from the vanilla game's own classes with a few hooks. Alpha/Beta: RenderGlobal's cloud render
# passes through CloudLayersGame (tools/Patch.java); alphabeta/CloudLayers.java is shared, <version>/CloudLayersGame.java
# holds the game's names. M:OE: moe/Patcher.java.
# Needs: JDK 8 (javac on PATH, for Alpha/Beta), JDK 17 at /usr/lib/jvm/java-17-openjdk, python3.
set -e
SRC=$(cd "$(dirname "$0")" && pwd); OUT=$(dirname "$SRC")
L=~/.local/share/PrismLauncher/libraries
ASM=$L/org/ow2/asm/asm/9.9/asm-9.9.jar:$L/org/ow2/asm/asm-tree/9.9/asm-tree-9.9.jar
LWJGL=$L/org/lwjgl/lwjgl/lwjgl/2.9.4-nightly-20150209/lwjgl-2.9.4-nightly-20150209.jar
J17=/usr/lib/jvm/java-17-openjdk/bin
OSE=${OSE:-$HOME/.local/share/PrismLauncher/instances/Minecraft.-.Oldschool.Edition/jarmods/d1ccfe5b-5558-4143-849a-f1daced8d831.jar}
B="$SRC/.build"; rm -rf "$B"; mkdir -p "$B/tools"
$J17/javac -d "$B/tools" -cp "$ASM" "$SRC/tools/Patch.java"
zipdir() {  # zipdir <zip> <folder>
  python3 - "$1" "$2" <<'PY'
import os, sys, zipfile
out, root = sys.argv[1:]
if os.path.exists(out): os.remove(out)
with zipfile.ZipFile(out, 'w', zipfile.ZIP_DEFLATED) as z:
    for d, _, fs in sorted(os.walk(root)):
        for f in sorted(fs): p = os.path.join(d, f); z.write(p, os.path.relpath(p, root))
PY
  ls -la "$1"
}
settings() {  # settings <out> <alpha|beta|moe>: the settings file for that version
  python3 - "$SRC/cloudlayers_settings.txt" "$1" "$2" <<'PY'
import sys
src, out, v = sys.argv[1:]
s = open(src).read()
s = s.replace('@VERSION@', {'alpha': 'Alpha 1.1.2_01', 'beta': 'Beta 1.7.3', 'moe': 'Minecraft Oldschool Edition'}[v])
if v == 'moe':
    s = s.replace('@BASE_NOTE@', ' auto = the game\'s own Cloud Height option (108 by default), or a number.').replace('@BASE@', 'auto')
    s = s.replace('@DISTANCE@', '')
    s = s.replace('@ALT_NOTE@', '\n# (The tint is added to the game\'s own cloud shader, so it costs no FPS; it works with the Vulkan renderer.)')
else:
    s = s.replace('@BASE_NOTE@', ' Vanilla fancy clouds sit at 108.').replace('@BASE@', '108')
    s = s.replace('@DISTANCE@', '''
# How far away clouds reach, as a multiple of your render distance (Far = 256 blocks, so 2.0 = 512). Clouds fade
# smoothly into the sky instead of being cut off at the edge of the render distance.
cloud_distance=2.0
# Never less than this many blocks.
min_cloud_distance=128
# Where the fade begins, as a fraction of the cloud distance (0.0 to 0.99).
fade_start=0.5
# These three apply on Far and Normal. Short and Tiny draw no sky, so there the clouds fade into the game's own
# fog like vanilla ones.
''')
    s = s.replace('@ALT_NOTE@', '')
assert '@' not in s
# an empty line before and after every setting, and never two in a row
def _set(l):
    t = l.strip(); return bool(t) and not t.startswith('#') and '=' in t
def _tidy(text):
    out = []
    for l in text.rstrip('\n').split('\n'):
        if l.strip():
            if out and out[-1].strip() and (_set(l) or _set(out[-1])): out.append('')
            out.append(l)
        elif out and out[-1].strip(): out.append('')
    return '\n'.join(out).rstrip('\n') + '\n'
open(out, 'w').write(_tidy(s))
PY
}

build_alphabeta() {  # build_alphabeta <a11201|b173> <RenderGlobal class> <game jar> <alpha|beta>
  local v=$1 rg=$2 MC=$3 W="$B/$1"
  mkdir -p "$W/game" "$W/zip"
  unzip -p "$MC" $rg.class > "$W/game/$rg.class"
  # RenderGlobal: b(F), the cloud render, passes through CloudLayersGame.render; the fields it reads are opened
  $J17/java -cp "$B/tools:$ASM" Patch "$W/game/$rg.class" "$W/zip/$rg.class" "hook:b(F)V=CloudLayersGame.render" "open=k,l,t,x"
  javac -nowarn -source 1.8 -target 1.8 -d "$W/zip" -cp "$W/zip:$MC:$LWJGL" "$SRC/alphabeta/CloudLayers.java" "$SRC/$v/CloudLayersGame.java"
  settings "$W/zip/cloudlayers_settings.txt" $4
  zipdir "$OUT/cloudlayers_$v.zip" "$W/zip"
}

build_a11201() {
  build_alphabeta a11201 e "$L/com/mojang/minecraft/a1.1.2_01/minecraft-a1.1.2_01-client.jar" alpha
}

build_b173() {
  build_alphabeta b173 n "$L/com/mojang/minecraft/b1.7.3/minecraft-b1.7.3-client.jar" beta
}

build_moe() {
  local W="$B/moe"
  mkdir -p "$W/patcher" "$W/zip" "$W/lowered"
  $J17/javac -d "$W/patcher" -cp "$ASM" "$SRC/moe/Patcher.java"
  $J17/java -cp "$W/patcher:$ASM" Patcher "$OSE" "$W/zip"
  # M:OE classes are Java 25 (class version 69); javac 17 reads them with the version lowered (compile only)
  python3 - "$OSE" "$W/stub.jar" "$W/zip" "$W/lowered" <<'PY'
import os, sys, zipfile
ose, stub, zipdir, low = sys.argv[1:]
with zipfile.ZipFile(ose) as zi, zipfile.ZipFile(stub, 'w') as zo:
    for n in zi.namelist():
        if n.endswith('.class'):
            b = bytearray(zi.read(n)); b[6:8] = (61).to_bytes(2, 'big'); zo.writestr(n, bytes(b))
for d, _, fs in os.walk(zipdir):
    for f in fs:
        if f.endswith('.class'):
            p = os.path.join(d, f); q = os.path.join(low, os.path.relpath(p, zipdir)); os.makedirs(os.path.dirname(q), exist_ok=True)
            b = bytearray(open(p, 'rb').read()); b[6:8] = (61).to_bytes(2, 'big'); open(q, 'wb').write(b)
PY
  $J17/javac -nowarn --release 17 -d "$W/zip" -cp "$W/lowered:$W/stub.jar" "$SRC/moe/net/minecraft/src/render/world/CloudLayers.java"
  settings "$W/zip/cloudlayers_settings.txt" moe
  zipdir "$OUT/cloudlayers_m:oe.zip" "$W/zip"
}

for v in ${@:-a11201 b173 moe}; do build_$v; done
rm -rf "$B"
