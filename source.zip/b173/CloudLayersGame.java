import java.awt.image.BufferedImage;
import java.io.InputStream;
import javax.imageio.ImageIO;

/**
 * Cloud Layers' link to Beta 1.7.3: everything CloudLayers needs from the game, by Beta's names.
 * RenderGlobal (n).b(F), the cloud render, passes through render(); the game's own is kept as cloudlayers$render.
 */
public final class CloudLayersGame {
    static n rg;
    static float pt;
    static final String CLOUDS = "/environment/clouds.png";

    private CloudLayersGame() {
    }

    public static void render(n r, float partial) {
        rg = r;
        pt = partial;
        if (!CloudLayers.render()) r.cloudlayers$render(partial);
    }

    /** A dimension without clouds (the Nether): the game's own render skips them. */
    static boolean noClouds() {
        return rg.t.f.t.c;
    }

    static double camX() {
        ls p = rg.t.i;
        return p.aJ + (p.aM - p.aJ) * (double) pt;
    }

    static double camY() {
        ls p = rg.t.i;
        return p.bm + (p.aN - p.bm) * (double) pt;
    }

    static double camZ() {
        ls p = rg.t.i;
        return p.aL + (p.aO - p.aL) * (double) pt;
    }

    /** 0 Far, 1 Normal, 2 Short, 3 Tiny. */
    static int renderDistance() {
        return rg.t.z.e;
    }

    static boolean fancyGraphics() {
        return rg.t.z.j;
    }

    static boolean anaglyph() {
        return rg.t.z.g;
    }

    static float[] cloudColor() {
        bt c = rg.k.c(pt);
        return new float[] {(float) c.a, (float) c.b, (float) c.c};
    }

    /** The sun's position: 0 noon, 0.25 sunset, 0.5 midnight, 0.75 sunrise. */
    static float celestialAngle() {
        return rg.k.b(pt);
    }

    /** Ticks for the cloud drift. */
    static float ticks() {
        return (float) rg.x + pt;
    }

    static int texture(String path) {
        return rg.l.b(path);
    }

    /** The texture pack in use. */
    static Object pack() {
        return rg.t.D != null ? rg.t.D.a : null;
    }

    /** A file of the texture pack in use, or of the game where the pack has none. */
    static BufferedImage image(String path) throws java.io.IOException {
        Object p = pack();
        InputStream in = p instanceof i ? ((i) p).a(path) : null;
        if (in == null) in = CloudLayersGame.class.getResourceAsStream(path);
        if (in == null) return null;
        try {
            return ImageIO.read(in);
        } finally {
            in.close();
        }
    }

    /** A texture made in code: a new one (id 0) or the same one again. */
    static int upload(BufferedImage im, int id) {
        if (id == 0) return rg.l.a(im);
        rg.l.a(im, id);
        return id;
    }

    static void begin() {
        nw.a.b();
    }

    static void color(float r, float g, float b, float a) {
        nw.a.a(r, g, b, a);
    }

    static void vertex(double x, double y, double z, double u, double v) {
        nw.a.a(x, y, z, u, v);
    }

    static void draw() {
        nw.a.a();
    }
}
