import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.zip.*;
import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;

/**
 * Cloud Layers' patches of Minecraft Oldschool Edition's own classes (nothing else in them changes):
 *   RenderGlobal                  renderClouds runs every layer (CloudLayers.render); per layer: fancy/flat, color,
 *                                 brightness, opacity, height, texture, drift time, flat texture scale, mesh cache
 *   GraphicsWeatherCloudColor     accepts flag 8 (alt_clouds)
 *   VulkanBuiltinShaderSources    the cloud vertex shader's alt_clouds face shading
 * Usage: Patcher <M:OE game jar> <outDir>
 */
public class Patcher implements Opcodes {
    static final String RG = "net/minecraft/src/render/world/RenderGlobal";
    static final String HOOK = "net/minecraft/src/render/world/CloudLayers";
    static final List<String> OPEN = List.of("mc", "renderEngine", "cloudMeshWorldDeformation", "cloudMeshDistanceScale",
        "fancyCloudStaticMesh", "fancyCloudStaticMeshRadius", "fancyCloudStaticMeshTextureWidth",
        "fancyCloudStaticMeshThickness", "fancyCloudStaticMeshFaceMask", "fancyCloudStaticMeshIsometricCapture");

    static final String CLOUD_COLOR = "net/minecraft/src/graphics/api/GraphicsWeatherCloudColor";
    static final String SHADERS = "net/minecraft/src/graphics/backend/vulkan/VulkanBuiltinShaderSources";

    public static void main(String[] a) throws Exception {
        try (ZipFile zip = new ZipFile(a[0])) {
            write(a[1], RG, patchClass(zip, RG, Patcher::patch));
            write(a[1], CLOUD_COLOR, patchClass(zip, CLOUD_COLOR, Patcher::patchCloudColor));
            write(a[1], SHADERS, patchClass(zip, SHADERS, Patcher::patchShaders));
        }
    }

    interface ClassPatch { void apply(ClassNode cn); }

    static byte[] patchClass(ZipFile zip, String name, ClassPatch patch) throws IOException {
        ClassNode cn = new ClassNode();
        try (InputStream in = zip.getInputStream(zip.getEntry(name + ".class"))) {
            new ClassReader(in.readAllBytes()).accept(cn, 0);
        }
        patch.apply(cn);
        ClassWriter cw = new ClassWriter(ClassWriter.COMPUTE_MAXS);
        cn.accept(cw);
        return cw.toByteArray();
    }

    static void write(String dir, String name, byte[] b) throws IOException {
        Path p = Paths.get(dir, name + ".class");
        Files.createDirectories(p.getParent());
        Files.write(p, b);
    }

    /** alt_clouds tags a layer's GPU cloud color with flag 8: isValid accepts flags 1|2|4 only, so also 8. */
    static void patchCloudColor(ClassNode cn) {
        MethodNode m = method(cn, "isValid", "()Z");
        int hits = 0;
        for (AbstractInsnNode n : m.instructions.toArray()) {
            if (n instanceof IntInsnNode i && i.getOpcode() == BIPUSH && i.operand == -8) {
                i.operand = -16;
                hits++;
            }
        }
        if (hits != 1) throw new IllegalStateException("isValid flag masks: " + hits);
    }

    /**
     * alt_clouds on the GPU: the cloud vertex shader's face shading (bottom 0.7, sides 0.9 / 0.8, top 1) gets the
     * Alpha/Beta alt_clouds formula when the cloud color has flag 8: linear in the shade from the cloud color at the
     * top to 0.7 * cloud * tint at the bottom, tint = 1 + 0.75 * (sky / luminance(sky) - 1). The flags and the sky
     * color reach the shader in the weather-cloud push data (worldFromLocal[1].w and [3].rgb); for the other cloud
     * draws worldFromLocal is a real transform, whose [1].w is 0.
     */
    static final String SHADE_OLD = "    float alpha = clamp(pushData.effects.x * alphaScale, 0.0, 1.0);\n"
        + "    return floor(clamp(vec4(tint * shade, alpha), vec4(0.0), vec4(1.0)) * 255.0) * (1.0 / 255.0);";
    static final String SHADE_NEW = "    float alpha = clamp(pushData.effects.x * alphaScale, 0.0, 1.0);\n"
        + "    vec3 cloudShade = vec3(shade);\n"
        + "    if (fancy && (int(floor(pushData.worldFromLocal[1].w + 0.5)) & 8) != 0) {\n"
        + "        vec3 altSky = pushData.worldFromLocal[3].rgb;\n"
        + "        float altLum = dot(altSky, vec3(0.3, 0.59, 0.11));\n"
        + "        vec3 altTint = vec3(1.0) + 0.75 * ((altLum > 0.001 ? altSky / altLum : vec3(1.0)) - vec3(1.0));\n"
        + "        cloudShade = vec3(1.0) + ((1.0 - shade) / 0.3) * (0.7 * altTint - vec3(1.0));\n"
        + "    }\n"
        + "    return floor(clamp(vec4(tint * cloudShade, alpha), vec4(0.0), vec4(1.0)) * 255.0) * (1.0 / 255.0);";

    static void patchShaders(ClassNode cn) {
        int hits = 0;
        for (FieldNode f : cn.fields) {
            if (f.value instanceof String v && v.contains(SHADE_OLD)) {
                f.value = v.replace(SHADE_OLD, SHADE_NEW);
                hits++;
            }
        }
        for (MethodNode m : cn.methods) {
            for (AbstractInsnNode n : m.instructions.toArray()) {
                if (n instanceof LdcInsnNode l && l.cst instanceof String v && v.contains(SHADE_OLD)) {
                    l.cst = v.replace(SHADE_OLD, SHADE_NEW);
                    hits++;
                }
                // "a" + b + "c" compiles to invokedynamic StringConcatFactory with the constant parts in a recipe string
                if (n instanceof InvokeDynamicInsnNode d) {
                    for (int k = 0; k < d.bsmArgs.length; k++) {
                        if (d.bsmArgs[k] instanceof String v && v.contains(SHADE_OLD)) {
                            d.bsmArgs[k] = v.replace(SHADE_OLD, SHADE_NEW);
                            hits++;
                        }
                    }
                }
            }
        }
        if (hits == 0) throw new IllegalStateException("cloud vertex shading not found in " + cn.name);
        System.out.println("Patcher: alt_clouds shading in " + hits + " shader source(s)");
    }

    static MethodNode method(ClassNode cn, String name, String desc) {
        for (MethodNode m : cn.methods) if (m.name.equals(name) && m.desc.equals(desc)) return m;
        throw new IllegalStateException("missing " + name + desc);
    }

    static int open(int acc) {
        return (acc & ~(ACC_PRIVATE | ACC_PROTECTED)) | ACC_PUBLIC;
    }

    static void patch(ClassNode cn) {
        int opened = 0;
        for (FieldNode f : cn.fields) if (OPEN.contains(f.name)) { f.access = open(f.access); opened++; }
        if (opened != OPEN.size()) throw new IllegalStateException("fields opened: " + opened);

        // renderClouds -> cl$renderClouds; new renderClouds draws every layer through CloudLayers.render.
        MethodNode orig = method(cn, "renderClouds", "(F)V");
        orig.name = "cl$renderClouds";
        orig.access = open(orig.access);
        MethodNode hook = new MethodNode(ACC_PUBLIC, "renderClouds", "(F)V", null, null);
        hook.instructions.add(new VarInsnNode(ALOAD, 0));
        hook.instructions.add(new VarInsnNode(FLOAD, 1));
        hook.instructions.add(new MethodInsnNode(INVOKESTATIC, HOOK, "render", "(L" + RG + ";F)V", false));
        hook.instructions.add(new InsnNode(RETURN));
        cn.methods.add(hook);

        // Per-layer fancy/fast choice.
        int hits = 0;
        for (AbstractInsnNode n : orig.instructions.toArray()) {
            if (n instanceof FieldInsnNode f && f.getOpcode() == GETFIELD && f.name.equals("fancyGraphics")) {
                orig.instructions.insert(n, new MethodInsnNode(INVOKESTATIC, HOOK, "fancy", "(Z)Z", false));
                hits++;
            }
        }
        if (hits != 1) throw new IllegalStateException("fancyGraphics reads: " + hits);

        // Per-layer brightness: both color sources of the flat and the fancy path go through CloudLayers.
        MethodNode fancyM = method(cn, "renderCloudsFancy", "(F)V");
        for (MethodNode m : new MethodNode[] {orig, fancyM}) {
            redirect(m, "net/minecraft/world/level/Level", "getWeatherCloudColorInputs",
                "(FZZ)Lnet/minecraft/src/graphics/api/GraphicsWeatherCloudColor;", "cloudInputs",
                "(Lnet/minecraft/world/level/Level;FZZ)Lnet/minecraft/src/graphics/api/GraphicsWeatherCloudColor;");
            redirect(m, "net/minecraft/world/level/Level", "func_628_d", "(F)Lnet/minecraft/src/world/core/Vec3D;",
                "cloudColor", "(Lnet/minecraft/world/level/Level;F)Lnet/minecraft/src/world/core/Vec3D;");
        }
        // Brightened 3D layers: the GPU draw's skyWorld flag (new GraphicsWeatherClouds(mesh, tex, color, alpha, u, v,
        // fancy=true, skyWorld=iload 2, ...)) and the CPU path's face shades (bottom 0.7, sides 0.9 / 0.8).
        brightFaces(fancyM);
        faceShades(fancyM);

        // Per-layer opacity: cloudAlpha = sky ? 0.6F : 0.8F  ->  CloudLayers.alpha(...)
        alpha(orig);
        alpha(method(cn, "renderCloudsFancy", "(F)V"));

        // Per-layer height.
        MethodNode h = method(cn, "getCloudRenderHeight", "()F");
        h.access = open(h.access);
        hits = 0;
        for (AbstractInsnNode n : h.instructions.toArray()) {
            if (n.getOpcode() == FRETURN) {
                h.instructions.insertBefore(n, new MethodInsnNode(INVOKESTATIC, HOOK, "height", "(F)F", false));
                hits++;
            }
        }
        if (hits == 0) throw new IllegalStateException("no FRETURN in getCloudRenderHeight");

        // Per-layer texture.
        MethodNode t = method(cn, "getCloudTexture", "()I");
        hits = 0;
        for (AbstractInsnNode n : t.instructions.toArray()) {
            if (n.getOpcode() == IRETURN) {
                t.instructions.insertBefore(n, new MethodInsnNode(INVOKESTATIC, HOOK, "texture", "(I)I", false));
                hits++;
            }
        }
        if (hits == 0) throw new IllegalStateException("no IRETURN in getCloudTexture");

        // Per-layer drift speed.
        MethodNode ct = method(cn, "getCloudTime", "(F)D");
        for (AbstractInsnNode n : ct.instructions.toArray()) {
            if (n.getOpcode() == DRETURN) {
                ct.instructions.insertBefore(n, new MethodInsnNode(INVOKESTATIC, HOOK, "time", "(D)D", false));
            }
        }

        // Flat layers use vanilla's fast-cloud texture scale (OSE's is 4x finer with a 256px texture).
        MethodNode sc = method(cn, "resolveCloudTextureScale", "(I)F");
        hits = 0;
        for (AbstractInsnNode n : sc.instructions.toArray()) {
            if (n.getOpcode() == FRETURN) {
                sc.instructions.insertBefore(n, new MethodInsnNode(INVOKESTATIC, HOOK, "flatScale", "(F)F", false));
                hits++;
            }
        }
        if (hits == 0) throw new IllegalStateException("no FRETURN in resolveCloudTextureScale");

        // Cached fancy meshes of the other layers must go whenever the game drops its own.
        MethodNode r = method(cn, "releaseCloudPlaneMeshCache", "()V");
        r.instructions.insert(new MethodInsnNode(INVOKESTATIC, HOOK, "releaseOthers", "()V", false));
    }

    /** Exactly one call of owner.name desc in m goes to the static CloudLayers.hook(owner, args...). */
    static void redirect(MethodNode m, String owner, String name, String desc, String hook, String hookDesc) {
        int hits = 0;
        for (AbstractInsnNode n : m.instructions.toArray()) {
            if (n instanceof MethodInsnNode c && c.getOpcode() == INVOKEVIRTUAL && c.owner.equals(owner) && c.name.equals(name) && c.desc.equals(desc)) {
                m.instructions.set(n, new MethodInsnNode(INVOKESTATIC, HOOK, hook, hookDesc, false));
                hits++;
            }
        }
        if (hits != 1) throw new IllegalStateException(name + " calls in " + m.name + ": " + hits);
    }

    static AbstractInsnNode real(AbstractInsnNode n, boolean forward) {
        do n = forward ? n.getNext() : n.getPrevious(); while (n != null && n.getOpcode() < 0);
        return n;
    }

    static void brightFaces(MethodNode m) {
        int hits = 0;
        for (AbstractInsnNode n : m.instructions.toArray()) {
            if (!(n instanceof TypeInsnNode t) || t.getOpcode() != NEW || !t.desc.equals("net/minecraft/src/graphics/api/GraphicsWeatherClouds")) continue;
            for (AbstractInsnNode k = n; k != null; k = k.getNext()) {
                if (k instanceof MethodInsnNode c && c.name.equals("<init>")) break;
                if (k.getOpcode() == ICONST_1 && real(k, true) instanceof VarInsnNode v && v.getOpcode() == ILOAD && v.var == 2) {
                    m.instructions.insert(v, new MethodInsnNode(INVOKESTATIC, HOOK, "brightFaces", "(Z)Z", false));
                    hits++;
                    break;
                }
            }
        }
        if (hits != 1) throw new IllegalStateException("skyWorld arguments in " + m.name + ": " + hits);
    }

    static void faceShades(MethodNode m) {
        // sky ? 0.95F : 0.7F -> local; sky ? 0.98F : 0.9F; sky ? 0.96F : 0.8F (the stores right after these constants)
        float[][] pairs = {{0.95F, 0.7F}, {0.98F, 0.9F}, {0.96F, 0.8F}};
        int hits = 0;
        for (float[] p : pairs) {
            for (AbstractInsnNode n : m.instructions.toArray()) {
                if (n.getOpcode() != FSTORE) continue;
                AbstractInsnNode prev = real(n, false);
                if (!(prev instanceof LdcInsnNode l) || !Float.valueOf(p[1]).equals(l.cst)) continue;
                AbstractInsnNode gotoI = real(prev, false), other = gotoI == null ? null : real(gotoI, false);
                if (gotoI == null || gotoI.getOpcode() != GOTO || !(other instanceof LdcInsnNode o) || !Float.valueOf(p[0]).equals(o.cst)) continue;
                m.instructions.insertBefore(n, new MethodInsnNode(INVOKESTATIC, HOOK, "faceShade", "(F)F", false));
                hits++;
                break;
            }
        }
        if (hits != 3) throw new IllegalStateException("face shade stores in " + m.name + ": " + hits);
    }

    static void alpha(MethodNode m) {
        int hits = 0;
        for (AbstractInsnNode n : m.instructions.toArray()) {
            if (n instanceof LdcInsnNode l && Float.valueOf(0.8F).equals(l.cst)) {
                AbstractInsnNode next = n.getNext();
                while (next != null && next.getOpcode() < 0) next = next.getNext();
                if (next != null && next.getOpcode() == FSTORE) {
                    m.instructions.insertBefore(next, new MethodInsnNode(INVOKESTATIC, HOOK, "alpha", "(F)F", false));
                    hits++;
                    break; // the first one is cloudAlpha (a later 0.8F is sideShadeZ in the fancy path)
                }
            }
        }
        if (hits != 1) throw new IllegalStateException(m.name + " cloudAlpha stores: " + hits);
    }
}
