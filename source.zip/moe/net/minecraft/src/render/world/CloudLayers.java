package net.minecraft.src.render.world;

import java.awt.image.BufferedImage;
import java.io.InputStream;
import java.util.Properties;
import javax.imageio.ImageIO;
import net.minecraft.src.graphics.api.GraphicsWeatherCloudColor;
import net.minecraft.src.render.core.GLAllocation;
import net.minecraft.src.world.core.Vec3D;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;

/**
 * Cloud Layers for Minecraft Oldschool Edition: three cloud layers instead of one, with the settings in
 * cloudlayers_settings.txt. RenderGlobal.renderClouds is renamed to cl$renderClouds and replaced by render(), which
 * runs the game's own cloud renderer once per layer (its GPU meshes, fog and shading). While a layer draws, the
 * patched RenderGlobal methods listed in Patcher pass through this class: height, opacity, fancy/flat, texture,
 * drift time, flat texture scale, color and face shading.
 *
 * Textures: layer 1 is the game's clouds texture; layers 2 and 3 (texture=auto) are made in code from the clouds
 * texture in use (resource packs included), turned and shifted so the layers never line up, and made again when
 * the game reloads its textures.
 *
 * alt_clouds: the shaded faces of layers 1 and 2 (when 3D) take 75% of the hue of the sky they are seen against: the
 * fog color, the sky at the horizon where the clouds fade out (it follows sunrise, sunset, night and weather); it fades out toward midnight. The
 * game's GPU cloud shader does the face shading, so the Patcher adds the formula there.
 */
public final class CloudLayers {
    static final int LAYERS = 3;
    static boolean enabled = true;
    static float baseHeight = Float.NaN; // NaN = use the game's Cloud Height option
    static float spacing = 32.0F;
    static float fastOffset = 0.0F;
    static final float[] alpha = {0.8F, 0.65F, 0.35F};
    static final float[] speed = {1.0F, 1.0F, 1.0F};
    /**
     * Color multiplier per layer. Below 1 the layer's cloud color is scaled down. Above 1 a 3D layer gets brighter
     * faces: the game's own bright cloud shading on the GPU path (undersides 95%, sides 98/96%, the sky-dimension
     * look), and the face shades times this value, capped at 1, on the other paths.
     */
    static final float[] brightness = {1.0F, 1.0F, 1.0F};
    /**
     * alt_clouds (see above): applies to cloud colors carrying flag ALT_FLAG, whose sky fields then hold the fog color.
     */
    static boolean altClouds = false;
    /** alt_clouds_night_fade: the tint fades out toward midnight (false = the same tint all night). */
    static boolean altNightFade = true;
    static final int ALT_FLAG = 8;
    static final float[] sky = {1.0F, 1.0F, 1.0F};
    static final boolean[] fancy = {true, true, false};
    /** "auto" = made from the clouds texture in use (layer 1: it as it is), else a png path in the jar / a pack. */
    static final String[] texture = {"auto", "auto", "auto"};
    static final String CLOUDS = "/assets/minecraft/textures/environment/clouds.png";
    /** Textures made in code for layers 2 and 3, and the game's texture generation they were made in. */
    static final int[] madeTexture = new int[LAYERS];
    static long madeGeneration = -1L;
    static RenderGlobal drawing;
    static boolean loaded;

    /** Layer currently being drawn, or -1 outside render() (everything passes through). */
    static int current = -1;
    static boolean currentFancy;

    /**
     * Each layer keeps its own fancy cloud mesh so they don't rebuild each other every frame.
     * Outside render() the RenderGlobal fields hold layer 0's mesh; `active` is whose mesh is there.
     */
    static int active = 0;
    static final int[] mesh = new int[LAYERS];
    static final int[] meshRadius = new int[LAYERS];
    static final int[] meshTextureWidth = new int[LAYERS];
    static final float[] meshThickness = new float[LAYERS];
    static final int[] meshFaceMask = new int[LAYERS];
    static final boolean[] meshIsometric = new boolean[LAYERS];

    static {
        for (int i = 0; i < LAYERS; i++) clear(i);
    }

    static void load() {
        loaded = true;
        Properties p = new Properties();
        try (InputStream in = CloudLayers.class.getResourceAsStream("/cloudlayers_settings.txt")) {
            if (in == null) return;
            p.load(in);
        } catch (Exception ex) {
            System.out.println("[CloudLayers] could not read cloudlayers_settings.txt: " + ex);
            return;
        }
        enabled = !"false".equalsIgnoreCase(p.getProperty("enabled", "true").trim());
        String base = p.getProperty("base_height", "auto").trim();
        baseHeight = base.equalsIgnoreCase("auto") ? Float.NaN : num(p, "base_height", Float.NaN);
        spacing = num(p, "spacing", spacing);
        fastOffset = num(p, "fast_offset", fastOffset);
        altClouds = "true".equalsIgnoreCase(p.getProperty("alt_clouds", "false").trim());
        altNightFade = !"false".equalsIgnoreCase(p.getProperty("alt_clouds_night_fade", "true").trim());
        for (int i = 0; i < LAYERS; i++) {
            String k = "layer" + (i + 1) + ".";
            alpha[i] = num(p, k + "alpha", alpha[i]);
            speed[i] = num(p, k + "speed", speed[i]);
            brightness[i] = Math.max(0.0F, num(p, k + "brightness", brightness[i]));
            texture[i] = p.getProperty(k + "texture", texture[i]).trim();
            fancy[i] = !"fast".equalsIgnoreCase(p.getProperty(k + "style", fancy[i] ? "fancy" : "fast").trim());
        }
    }

    static float num(Properties p, String key, float def) {
        String v = p.getProperty(key);
        if (v == null) return def;
        try {
            return Float.parseFloat(v.trim());
        } catch (NumberFormatException ex) {
            System.out.println("[CloudLayers] bad value for " + key + ": " + v);
            return def;
        }
    }

    public static void render(RenderGlobal rg, float pt) {
        if (!loaded) load();
        LivingEntity view = rg.mc != null ? rg.mc.renderViewEntity : null;
        if (!enabled || view == null || current >= 0) {
            rg.cl$renderClouds(pt);
            return;
        }

        float gameHeight = rg.getCloudRenderHeight();
        float base = Float.isNaN(baseHeight) ? gameHeight : baseHeight;
        double camY = view.lastTickPosY + (view.posY - view.lastTickPosY) * (double) pt;

        // Farthest layer first so the translucent layers blend correctly.
        int[] order = new int[LAYERS];
        for (int i = 0; i < LAYERS; i++) order[i] = i;
        for (int i = 0; i < LAYERS; i++) {
            for (int j = i + 1; j < LAYERS; j++) {
                if (Math.abs(base + spacing * order[j] - camY) > Math.abs(base + spacing * order[i] - camY)) {
                    int t = order[i]; order[i] = order[j]; order[j] = t;
                }
            }
        }

        boolean fancyGfx = rg.mc.gameSettings != null && rg.mc.gameSettings.fancyGraphics;
        if (altClouds && fancyGfx) setSkyTint(rg, pt);
        drawing = rg;
        for (int n = 0; n < LAYERS; n++) {
            int i = order[n];
            if (alpha[i] <= 0.0F) continue;
            swapIn(rg, i);
            current = i;
            currentFancy = fancyGfx && fancy[i];
            try {
                rg.cl$renderClouds(pt);
            } finally {
                current = -1;
                swapOut(rg, i);
            }
        }
    }

    // --- hooks called from the patched RenderGlobal ---

    public static boolean fancy(boolean gameFancy) {
        return current < 0 ? gameFancy : gameFancy && fancy[current];
    }

    public static float alpha(float vanilla) {
        return current < 0 ? vanilla : vanilla * (alpha[current] / 0.8F);
    }

    public static float height(float gameHeight) {
        if (current < 0) return gameHeight;
        float base = Float.isNaN(baseHeight) ? gameHeight : baseHeight;
        return base + spacing * (float) current + (currentFancy ? 0.0F : fastOffset);
    }

    /** RenderGlobal.getCloudTexture: the texture of the layer being drawn. */
    public static int texture(int gameTexture) {
        if (current < 0 || drawing == null) return gameTexture;
        String t = texture[current];
        if (!t.equalsIgnoreCase("auto")) return drawing.renderEngine.getTexture(t);
        if (current == 0) return gameTexture;
        long gen = drawing.renderEngine.getTextureResourceGeneration();
        if (gen != madeGeneration || madeTexture[current] == 0) {
            madeGeneration = gen;
            try {
                BufferedImage src = cloudsImage(drawing);
                if (src != null)
                    for (int k = 1; k < LAYERS; k++) {
                        BufferedImage im = layerImage(src, k);
                        if (madeTexture[k] == 0) madeTexture[k] = drawing.renderEngine.allocateAndSetupTexture(im);
                        else drawing.renderEngine.setupTexture(im, madeTexture[k]);
                    }
            } catch (Exception ex) {
                System.out.println("[CloudLayers] could not make the layer textures: " + ex);
            }
        }
        return madeTexture[current] != 0 ? madeTexture[current] : gameTexture;
    }

    /** The game's clouds texture image from the packs in use (or the game). */
    static BufferedImage cloudsImage(RenderGlobal rg) throws java.io.IOException {
        InputStream in = rg.renderEngine.getAssetsResourceStream(CLOUDS);
        if (in == null) in = rg.renderEngine.getResourceAsStream(CLOUDS);
        if (in == null) return null;
        try (InputStream i = in) {
            return ImageIO.read(i);
        }
    }

    /**
     * Layer 2: clouds.png turned 90 degrees left and shifted by (97, 41) of 256. Layer 3: mirrored, turned 90 degrees
     * right and shifted by (173, 131) of 256. Shifts scale with the texture size.
     */
    static BufferedImage layerImage(BufferedImage src, int layer) {
        int n = Math.min(src.getWidth(), src.getHeight());
        int dx = (layer == 1 ? 97 : 173) * n / 256, dy = (layer == 1 ? 41 : 131) * n / 256;
        BufferedImage out = new BufferedImage(n, n, BufferedImage.TYPE_INT_ARGB);
        for (int y = 0; y < n; y++)
            for (int x = 0; x < n; x++) {
                int sx = Math.floorMod(x - dx, n), sy = Math.floorMod(y - dy, n);
                out.setRGB(x, y, layer == 1 ? src.getRGB(n - 1 - sy, sx) : src.getRGB(n - 1 - sy, n - 1 - sx));
            }
        return out;
    }

    /**
     * Texture scale of flat layers. OSE uses 0.5 / textureWidth, which with the 256px cloud
     * texture makes each texel 2 blocks wide; vanilla fast clouds (and the Alpha/Beta versions
     * of this mod) use 1/2048, 8 blocks per texel. Fancy layers don't go through this.
     */
    public static float flatScale(float gameScale) {
        return current < 0 || currentFancy ? gameScale : 4.8828125E-4F;
    }

    public static double time(double gameTime) {
        return current < 0 ? gameTime : gameTime * (double) speed[current];
    }

    /** alt_clouds: this frame's fog color (the sky at the horizon, where the clouds fade into it). */
    static void setSkyTint(RenderGlobal rg, float pt) {
        EntityRenderer er = rg.mc.entityRenderer;
        if (er == null) return;
        sky[0] = Math.max(0.0F, Math.min(1.0F, er.fogColorRed));
        sky[1] = Math.max(0.0F, Math.min(1.0F, er.fogColorGreen));
        sky[2] = Math.max(0.0F, Math.min(1.0F, er.fogColorBlue));
        if ((altNightFade || TEST_MIX != 1.0F) && rg.mc.theWorld != null) {
            // full all day; from sunset it eases down to none at midnight and back up to full by sunrise: the sky color
            // is moved toward its own gray by k, which scales the shader's tint by k (brightness kept)
            float k = altNightFade ? Math.max(0.0F, Math.min(1.0F, 1.0F + (float) Math.cos(rg.mc.theWorld.getCelestialAngle(pt) * Math.PI * 2.0D))) : 1.0F;
            k *= TEST_MIX;
            float lum = sky[0] * 0.3F + sky[1] * 0.59F + sky[2] * 0.11F;
            for (int c = 0; c < 3; c++) sky[c] = Math.max(0.0F, Math.min(1.0F, lum + k * (sky[c] - lum)));
        }
    }

    /** -Dcloudlayers.skymix=N: another mix than the shader's 75% (tests only, up to 75). */
    static final float TEST_MIX = Float.parseFloat(System.getProperty("cloudlayers.skymix", "75")) / 75.0F;

    /** alt_clouds applies to the layer being drawn (layer 1 or 2, drawn 3D). */
    static boolean altActive() {
        return altClouds && current >= 0 && current <= 1 && currentFancy;
    }

    /** Color factor of the layer being drawn: its brightness, capped at 1 (the GPU path takes colors up to 1). */
    static float[] colorFactors() {
        float k = current < 0 ? 1.0F : Math.min(1.0F, brightness[current]);
        return new float[] {k, k, k};
    }

    static boolean unit(float[] f) {
        return f[0] == 1.0F && f[1] == 1.0F && f[2] == 1.0F;
    }

    /**
     * Level.getWeatherCloudColorInputs in renderClouds / renderCloudsFancy (GPU path): the layer's color factors, and
     * for alt_clouds flag ALT_FLAG plus this frame's fog color in the sky fields (kept as is in sky dimensions, which
     * blend with their own).
     */
    public static GraphicsWeatherCloudColor cloudInputs(Level w, float pt, boolean skyWorld, boolean anaglyph) {
        GraphicsWeatherCloudColor c = w.getWeatherCloudColorInputs(pt, skyWorld, anaglyph);
        float[] f = colorFactors();
        boolean alt = altActive();
        if (c == null || (unit(f) && !alt)) return c;
        boolean blend = (c.flags() & GraphicsWeatherCloudColor.SKY_BLEND) != 0;
        return new GraphicsWeatherCloudColor(c.weatherFrame(), c.previousThunder(), c.currentThunder(), c.daylight(),
            c.lightningFlashTicks(), alt ? c.flags() | ALT_FLAG : c.flags(), c.cloudRed() * f[0], c.cloudGreen() * f[1],
            c.cloudBlue() * f[2], alt && !blend ? sky[0] : c.skyRed(), alt && !blend ? sky[1] : c.skyGreen(),
            alt && !blend ? sky[2] : c.skyBlue(), c.anaglyph());
    }

    /** Level.func_628_d (cloud color) in renderClouds / renderCloudsFancy (other paths): the layer's color factors. */
    public static Vec3D cloudColor(Level w, float pt) {
        Vec3D v = w.func_628_d(pt);
        float[] f = colorFactors();
        if (unit(f)) return v;
        return Vec3D.createVector(v.xCoord * f[0], v.yCoord * f[1], v.zCoord * f[2]);
    }

    /** The skyWorld flag of a 3D layer's GPU draw: set for brightened layers (the game's bright face shading). */
    public static boolean brightFaces(boolean sky) {
        return sky || (current >= 0 && currentFancy && brightness[current] > 1.0F);
    }

    /** Bottom / side face shades of the CPU fancy path, times the layer's brightness above 1 (capped at 1). */
    public static float faceShade(float shade) {
        if (current < 0 || brightness[current] <= 1.0F) return shade;
        return Math.min(1.0F, shade * brightness[current]);
    }

    /** RenderGlobal is dropping its cloud meshes: drop the other layers' stored fancy meshes too. */
    public static void releaseOthers() {
        for (int j = 0; j < LAYERS; j++) {
            if (j == active) continue;
            if (mesh[j] > 0) GLAllocation.deleteStaticMesh(mesh[j]);
            clear(j);
        }
    }

    // --- per-layer fancy mesh cache ---

    static void clear(int i) {
        mesh[i] = 0;
        meshRadius[i] = -1;
        meshTextureWidth[i] = -1;
        meshThickness[i] = -1.0F;
        meshFaceMask[i] = -1;
        meshIsometric[i] = false;
    }

    static void save(RenderGlobal rg, int i) {
        mesh[i] = rg.fancyCloudStaticMesh;
        meshRadius[i] = rg.fancyCloudStaticMeshRadius;
        meshTextureWidth[i] = rg.fancyCloudStaticMeshTextureWidth;
        meshThickness[i] = rg.fancyCloudStaticMeshThickness;
        meshFaceMask[i] = rg.fancyCloudStaticMeshFaceMask;
        meshIsometric[i] = rg.fancyCloudStaticMeshIsometricCapture;
    }

    static void restore(RenderGlobal rg, int i) {
        rg.fancyCloudStaticMesh = mesh[i];
        rg.fancyCloudStaticMeshRadius = meshRadius[i];
        rg.fancyCloudStaticMeshTextureWidth = meshTextureWidth[i];
        rg.fancyCloudStaticMeshThickness = meshThickness[i];
        rg.fancyCloudStaticMeshFaceMask = meshFaceMask[i];
        rg.fancyCloudStaticMeshIsometricCapture = meshIsometric[i];
        clear(i);
    }

    static void swapIn(RenderGlobal rg, int i) {
        if (i == 0) return;
        save(rg, 0);
        restore(rg, i);
        active = i;
    }

    static void swapOut(RenderGlobal rg, int i) {
        if (i == 0) return;
        save(rg, i);
        restore(rg, 0);
        active = 0;
    }
}
