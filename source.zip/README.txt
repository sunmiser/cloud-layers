Cloud Layers - source (remade 2026-10-22)

  ./build.sh [a11201] [b173] [moe]   -> cloudlayers_a11201.zip, cloudlayers_b173.zip, cloudlayers_m:oe.zip in the
                                         folder above (no argument: all three)

Every zip is built from the vanilla game's own classes with a few hooks; settings in cloudlayers_settings.txt
(template here, filled in per version by build.sh).

  alphabeta/CloudLayers.java   all of the Alpha/Beta mod: layers, distance fade, display lists, alt_clouds, textures
  a11201/, b173/CloudLayersGame.java   the only code that knows the game's names (camera, settings, cloud color,
                                textures, tessellator); RenderGlobal's cloud render b(F) passes through it
  tools/Patch.java             Alpha/Beta patch tool: hook b(F) of RenderGlobal (e / n), open the fields k,l,t,x
  moe/net/.../CloudLayers.java the M:OE mod: runs the game's own cloud renderer once per layer
  moe/Patcher.java             M:OE patches: RenderGlobal (render per layer; height, opacity, fancy/flat, color,
                                brightness, texture, drift time, flat texture scale, mesh cache), GraphicsWeatherCloudColor
                                (flag 8), VulkanBuiltinShaderSources (the cloud shader's alt_clouds shading)

Looks (picked by the user 2026-10-18): layer alphas 0.8 / 0.65 / 0.35, brightness 1, layer 3 flat; alt_clouds off by
default: layers 1-2's shaded faces get 75% of the sky's hue (picked 2026-10-23 from 30/50/75/100%, close to the user's reference screenshot). The sky color used is the fog color the game set for the
frame, i.e. the sky at the horizon where the clouds fade into it (before 2026-10-22: the sky color straight up, which
read purplish); it follows sunrise, sunset, night, weather and Warmlighting's fog.
Textures: layer 1 = the clouds texture in use; layers 2 and 3 are made in code from it (turned 90 degrees left and
shifted 97,41 / mirrored, turned right and shifted 173,131 of 256 - pixel-identical to the PNGs earlier versions
shipped), so texture packs and resource packs change every layer. Remade when the pack changes (Beta: the selected
pack; M:OE: RenderEngine.getTextureResourceGeneration).

Tests (real games; tests/game-test-harness, WORK = the harness work folder):
  run_compare.sh <a11201|b173|moe> <out> name=zip...   noon up/horizon, sunset, night, alt off/on, Graphics Fast;
                                                        diff.py <out> <name> <name> compares two zips
  run_pack.sh <b173|moe> <out> <zip> [pack]             layer 2 / layer 3 alone without and with a pack
Results 2026-10-22: default look identical to the previous build in all three (mean colour equal, only frame noise
differs); alt_clouds a little less blue by day and at sunset, a little bluer at night; a checker-pattern pack shows
on layers 2 and 3 in Beta and M:OE; FPS unchanged.
