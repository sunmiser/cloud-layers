import java.awt.image.BufferedImage;
import java.io.InputStream;
import javax.imageio.ImageIO;

/**
 * Cloud Layers' link to Alpha 1.1.2_01: everything CloudLayers needs from the game, by Alpha's names.
 * RenderGlobal (e).b(F), the cloud render, passes through render(); the game's own is kept as cloudlayers$render.
 */
public final class CloudLayersGame {
    static e rg;
    static float pt;
    static final String CLOUDS = "/clouds.png";

    private CloudLayersGame() {
    }

    public static void render(e r, float partial) {
        rg = r;
        pt = partial;
        if (!CloudLayers.render()) r.cloudlayers$render(partial);
    }

    /** Alpha has no dimensions without clouds. */
    static boolean noClouds() {
        return false;
    }

    static double camX() {
        bi p = rg.t.g;
        return p.ah + (p.ak - p.ah) * (double) pt;
    }

    static double camY() {
        bi p = rg.t.g;
        return p.aJ + (p.al - p.aJ) * (double) pt;
    }

    static double camZ() {
        bi p = rg.t.g;
        return p.aj + (p.am - p.aj) * (double) pt;
    }

    /** 0 Far, 1 Normal, 2 Short, 3 Tiny. */
    static int renderDistance() {
        return rg.t.y.e;
    }

    static boolean fancyGraphics() {
        return rg.t.y.i;
    }

    static boolean anaglyph() {
        return rg.t.y.g;
    }

    static float[] cloudColor() {
        aj c = rg.k.d(pt);
        return new float[] {(float) c.a, (float) c.b, (float) c.c};
    }

    /** The sun's position: 0 noon, 0.25 sunset, 0.5 midnight, 0.75 sunrise. */
    static float celestialAngle() {
        return rg.k.c(pt);
    }

    /** Ticks for the cloud drift. */
    static float ticks() {
        return (float) rg.x + pt;
    }

    static int texture(String path) {
        return rg.l.a(path);
    }

    /** The texture pack in use (Alpha has none). */
    static Object pack() {
        return null;
    }

    static BufferedImage image(String path) throws java.io.IOException {
        try (InputStream in = CloudLayersGame.class.getResourceAsStream(path)) {
            return in == null ? null : ImageIO.read(in);
        }
    }

    /** A texture made in code: a new one (id 0) or the same one again. */
    static int upload(BufferedImage im, int id) {
        if (id == 0) return rg.l.a(im);
        rg.l.a(im, id);
        return id;
    }

    static void begin() {
        ho.a.b();
    }

    static void color(float r, float g, float b, float a) {
        ho.a.a(r, g, b, a);
    }

    static void vertex(double x, double y, double z, double u, double v) {
        ho.a.a(x, y, z, u, v);
    }

    static void draw() {
        ho.a.a();
    }
}
