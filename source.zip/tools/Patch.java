import java.nio.file.*;
import java.util.*;
import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;

/**
 * Cloud Layers' patch tool for Alpha/Beta: small hooks into the game's own classes (nothing else in them changes).
 *   java Patch in.class out.class op...
 * Ops:
 *   hook:NAME(DESC)=Helper.method
 *       The method calls the static helper with (this, its arguments) and returns what the helper returns. The game's
 *       code stays callable as cloudlayers$method; if the class does not declare the method, cloudlayers$method calls
 *       the inherited one.
 *   call:Owner.NAME(DESC)=Helper.method#N
 *       Every call of that method inside the class goes to the static helper instead, which gets the receiver first.
 *       Exactly N calls must be found.
 *   init=Helper.method
 *       The static initializer calls the helper first.
 *   open=field,field...
 *       Those fields become public (the helper reads them).
 * Helper descriptors follow from the ops. The added code has no branches, so no stack map frames are needed.
 */
public class Patch {
    public static void main(String[] a) throws Exception {
        ClassNode cn = new ClassNode();
        new ClassReader(Files.readAllBytes(Paths.get(a[0]))).accept(cn, 0);
        for (int i = 2; i < a.length; i++) {
            String op = a[i];
            if (op.startsWith("hook:")) hook(cn, op.substring(5));
            else if (op.startsWith("call:")) call(cn, op.substring(5));
            else if (op.startsWith("init=")) init(cn, op.substring(5));
            else if (op.startsWith("open=")) open(cn, op.substring(5));
            else throw new IllegalArgumentException("unknown op " + op);
        }
        ClassWriter cw = new ClassWriter(ClassWriter.COMPUTE_MAXS);
        cn.accept(cw);
        Files.write(Paths.get(a[1]), cw.toByteArray());
    }

    /** "Owner/Class.method" -> {owner, method} (the last dot). */
    static String[] helper(String s) {
        int d = s.lastIndexOf('.');
        return new String[] {s.substring(0, d), s.substring(d + 1)};
    }

    static void hook(ClassNode cn, String spec) {
        String sig = spec.substring(0, spec.indexOf('=')), name = sig.substring(0, sig.indexOf('(')), desc = sig.substring(name.length());
        String[] h = helper(spec.substring(spec.indexOf('=') + 1));
        String kept = "cloudlayers$" + h[1];
        Type[] args = Type.getArgumentTypes(desc);
        Type ret = Type.getReturnType(desc);
        MethodNode m = null;
        for (MethodNode k : cn.methods) if (k.name.equals(name) && k.desc.equals(desc)) m = k;
        int access = Opcodes.ACC_PUBLIC;
        if (m != null) {
            if ((m.access & Opcodes.ACC_STATIC) != 0) throw new IllegalStateException(name + desc + " is static");
            access = m.access & ~(Opcodes.ACC_SYNCHRONIZED | Opcodes.ACC_FINAL);
            // the game's code, under the new name (public: the helper calls it)
            m.name = kept;
            m.access = (m.access & ~(Opcodes.ACC_PRIVATE | Opcodes.ACC_PROTECTED)) | Opcodes.ACC_PUBLIC;
        } else {
            // not declared here: the kept name calls the inherited method
            MethodNode s = new MethodNode(Opcodes.ACC_PUBLIC, kept, desc, null, null);
            s.instructions.add(new VarInsnNode(Opcodes.ALOAD, 0));
            loadArgs(s.instructions, args);
            s.instructions.add(new MethodInsnNode(Opcodes.INVOKESPECIAL, cn.superName, name, desc, false));
            s.instructions.add(new InsnNode(ret.getOpcode(Opcodes.IRETURN)));
            cn.methods.add(s);
        }
        MethodNode n = new MethodNode(access, name, desc, null, m != null ? m.exceptions.toArray(new String[0]) : null);
        n.instructions.add(new VarInsnNode(Opcodes.ALOAD, 0));
        loadArgs(n.instructions, args);
        n.instructions.add(new MethodInsnNode(Opcodes.INVOKESTATIC, h[0], h[1], "(L" + cn.name + ";" + desc.substring(1), false));
        n.instructions.add(new InsnNode(ret.getOpcode(Opcodes.IRETURN)));
        cn.methods.add(n);
        System.out.println("Patch: " + cn.name + "." + name + desc + " -> " + h[0] + "." + h[1] + (m != null ? " (game code: " : " (inherited: ") + kept + ")");
    }

    static void loadArgs(InsnList l, Type[] args) {
        int slot = 1;
        for (Type t : args) {
            l.add(new VarInsnNode(t.getOpcode(Opcodes.ILOAD), slot));
            slot += t.getSize();
        }
    }

    static void call(ClassNode cn, String spec) {
        String sig = spec.substring(0, spec.indexOf('=')), target = spec.substring(spec.indexOf('=') + 1);
        String ownerName = sig.substring(0, sig.indexOf('(')), desc = sig.substring(ownerName.length());
        String[] om = helper(ownerName), h = helper(target.substring(0, target.indexOf('#')));
        int want = Integer.parseInt(target.substring(target.indexOf('#') + 1)), found = 0;
        for (MethodNode m : cn.methods)
            for (AbstractInsnNode i : m.instructions.toArray()) {
                if (i.getOpcode() != Opcodes.INVOKEVIRTUAL) continue;
                MethodInsnNode c = (MethodInsnNode) i;
                if (!c.owner.equals(om[0]) || !c.name.equals(om[1]) || !c.desc.equals(desc)) continue;
                m.instructions.set(c, new MethodInsnNode(Opcodes.INVOKESTATIC, h[0], h[1], "(L" + om[0] + ";" + desc.substring(1), false));
                found++;
            }
        if (found != want) throw new IllegalStateException(found + " calls of " + ownerName + desc + " in " + cn.name + ", expected " + want);
        System.out.println("Patch: " + cn.name + ": " + found + " call(s) of " + om[1] + desc + " -> " + h[0] + "." + h[1]);
    }

    static void init(ClassNode cn, String target) {
        String[] h = helper(target);
        MethodNode m = null;
        for (MethodNode k : cn.methods) if (k.name.equals("<clinit>")) m = k;
        if (m == null) {
            m = new MethodNode(Opcodes.ACC_STATIC, "<clinit>", "()V", null, null);
            m.instructions.add(new InsnNode(Opcodes.RETURN));
            cn.methods.add(m);
        }
        m.instructions.insert(new MethodInsnNode(Opcodes.INVOKESTATIC, h[0], h[1], "()V", false));
        System.out.println("Patch: " + cn.name + ".<clinit> calls " + h[0] + "." + h[1]);
    }

    static void open(ClassNode cn, String names) {
        List<String> want = Arrays.asList(names.split(","));
        int n = 0;
        for (FieldNode f : cn.fields)
            if (want.contains(f.name)) {
                f.access = (f.access & ~(Opcodes.ACC_PRIVATE | Opcodes.ACC_PROTECTED)) | Opcodes.ACC_PUBLIC;
                n++;
            }
        if (n != want.size()) throw new IllegalStateException(n + " of the fields " + names + " found in " + cn.name);
        System.out.println("Patch: " + cn.name + " fields " + names + " are public");
    }
}
